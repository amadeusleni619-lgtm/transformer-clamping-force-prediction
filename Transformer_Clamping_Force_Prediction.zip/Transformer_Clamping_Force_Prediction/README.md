# One-Hour-Ahead Prediction of Power Transformer Winding Clamping Force

Reproducibility package for the study **“Prediction of Power Transformer Winding Clamping Force at a One-Hour-Ahead Horizon”**.

This repository contains the Python scripts used to prepare the transformer monitoring data, construct the three predictive formulations (A, B, and C), train seven machine-learning architectures, and evaluate their one-hour-ahead predictions.

> **Data rights notice.** The original monitoring dataset is not included in this repository. It is available from its original Zenodo record (see [Source dataset](#source-dataset-and-data-rights)). The record identifies SINTEF Energi AS as copyright holder. Do not redistribute the original CSV, or derived record-level files that reproduce its measurements, unless the applicable permissions allow it.

## 1. Study overview

The prediction task is a rolling one-step-ahead forecast. Each input window contains 24 consecutive hourly observations, from \(t-23\) h through \(t\), and the target is the measured clamping force at exactly \(t+1\) h.

Seven architectures are compared:

- Ridge regression;
- Random Forest;
- XGBoost;
- support vector regression with an RBF kernel (SVR-RBF);
- multilayer perceptron (MLP);
- long short-term memory network (LSTM);
- gated recurrent unit network (GRU).

Three predictive formulations are considered:

| Formulation | Model inputs | Prediction target | Use of the current measured force |
|---|---|---|---|
| **A** | Nine electrothermal variables and the 24-hour measured-force history | Absolute force \(F(t+1)\) | The preceding 24-hour force history is included in the input sequence. |
| **B** | Nine electrothermal variables only | Absolute force \(F(t+1)\) | Excluded from model inputs; used separately for the persistence baseline. |
| **C** | Nine electrothermal variables only | Force increment \(\Delta F(t+1)=F(t+1)-F(t)\) | The measured \(F(t)\) is used only to reconstruct \(\hat F(t+1)=F(t)+\widehat{\Delta F}(t+1)\); it is not a model input feature. |

The nine electrothermal variables are:

1. Voltage [kV]
2. Current [A]
3. Ambient [degC]
4. Top oil [degC]
5. Bottom oil [degC]
6. Mid-spot HV [degC]
7. Mid-spot LV [degC]
8. Hot-spot HV [degC]
9. Hot-spot LV [degC]

Formulation C is therefore a **measurement-conditioned incremental prediction method**, not a sensorless absolute-force estimator.

## 2. Repository structure

The scripts are expected to be stored in `scripts/`, one directory below the project root. The source CSV is expected under `data/raw/`.

```text
Transformer_Clamping_Force_Prediction/
├── data/
│   └── raw/
│       └── Barug2025_sensordata.csv       # downloaded separately; not redistributed here
├── scripts/
│   ├── 00_prepare_audited_series_and_build_scenario_A_t_plus_1h.py
│   ├── 01_build_dataset_scenario_B_electrothermal_t_plus_1h.py
│   ├── 02_train_compare_architectures_scenarios_A_B_t_plus_1h.py
│   └── 03_build_and_train_scenario_C_deltaF_t_plus_1h.py
├── resultats_prediction_t_plus_1h_modele_B/
├── resultats_scenario_B_electrothermique_t_plus_1h/
├── resultats_comparaison_architectures_t_plus_1h/
├── resultats_scenario_C_variation_force_t_plus_1h/
├── README.md
├── requirements.txt
└── environment.yml
```

The directory name `resultats_prediction_t_plus_1h_modele_B` is retained because the downstream scripts refer to it. In the manuscript's current terminology, the dataset generated there is **Formulation A** (electrothermal variables plus mechanical-force history).

The scripts use paths relative to the project root, based on `Path(__file__).resolve().parent.parent`. If you change the directory layout or script filenames, update the corresponding paths in the configuration sections before running the scripts.

## 3. Source dataset and data rights

The source measurements are provided by:

H. Bærug, I. Madshaven, and C. Espedal, *Supporting data for thermomechanical modelling of clamping force in power transformer in operation*, Zenodo (2025). DOI: [10.5281/zenodo.17223516](https://doi.org/10.5281/zenodo.17223516).

Download the source file and place it at:

```text
data/raw/Barug2025_sensordata.csv
```

The original dataset record identifies SINTEF Energi AS as copyright holder. The public availability of the dataset does not, by itself, establish permission to redistribute it. This repository therefore does not include the original source file. Before publishing derived datasets or record-level predictions, check that their redistribution is permitted under the source dataset's applicable terms or obtain permission from the rights holder.

The scripts can regenerate the analysis datasets locally from the source file, subject to the configuration and data availability described below.

## 4. Software requirements

The scripts require Python 3.10 or later. Python 3.11 is the reference environment specified in `environment.yml`.

Main dependencies:

- NumPy and pandas for data handling;
- scikit-learn for preprocessing and classical machine-learning models;
- XGBoost for gradient-boosted trees;
- PyTorch for MLP, LSTM, and GRU models;
- Matplotlib for figures;
- Joblib for saving classical models and scalers.

Additional file-format dependencies:

- `openpyxl` for `.xlsx` files;
- `xlrd` for legacy `.xls` files;
- `pyarrow` for Parquet files.

The campaign's exact Python and package versions were not recorded in the original execution files. Consequently, the dependency versions in `requirements.txt` and `environment.yml` are **compatible version ranges for setting up a new environment**; they are not a claim that these were the exact versions used in the original campaign. For strict historical reproduction, the original execution environment would need to be recovered.

### Option A — Create the Conda environment

From the project root:

```bash
conda env create -f environment.yml
conda activate transformer-clamping-force
```

### Option B — Create a Python virtual environment with pip

From the project root:

```bash
python -m venv .venv
```

Activate it:

```bash
# Windows PowerShell
.venv\Scripts\Activate.ps1

# Linux / macOS
source .venv/bin/activate
```

Install the packages:

```bash
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

PyTorch installation can depend on the operating system and whether CPU or CUDA execution is intended. Consult the [official PyTorch installation selector](https://pytorch.org/get-started/locally/) if a platform-specific build is required. The scripts automatically use CUDA when available and otherwise use the CPU.

## 5. Execution order

Run the scripts from the project root, in the following order. The scripts use their own project-root-relative paths, so the current working directory should not affect file resolution, provided the expected folder structure is preserved.

### Step 00 — Audit the source data and construct Formulation A

```bash
python scripts/00_prepare_audited_series_and_build_scenario_A_t_plus_1h.py
```

Input:

```text
data/raw/Barug2025_sensordata.csv
```

Main outputs in `resultats_prediction_t_plus_1h_modele_B/` include:

- `serie_horaire_auditee.csv`;
- `jeu_donnees_dynamique_complet_t_plus_1h.csv`;
- chronological train, validation, and test CSV files;
- an NPZ file containing sequential and flattened arrays;
- missing-value, outlier, column-selection, and temporal-gap audits;
- a persistence-baseline report, figures, and experimental metadata.

**Before proceeding:** inspect the generated audit reports. Confirm that the selected predictors are exactly the intended nine electrothermal variables, that the target is the measured clamping force, that its unit is kN, and that no unintended variable has entered the input features. The preparation script's automatic predictor selection should be checked against the intended feature list; configure `FEATURE_COLUMNS` explicitly where appropriate.

The script does not interpolate missing hourly measurements. It rejects windows that do not contain all required consecutive hourly inputs and a valid target at \(t+1\) h. Duplicate timestamps, if present, are handled according to the configured duplicate policy; the duplicate audit should be reviewed before accepting the resulting series.

### Step 01 — Construct Formulation B

```bash
python scripts/01_build_dataset_scenario_B_electrothermal_t_plus_1h.py
```

This script reads `serie_horaire_auditee.csv` and the Formulation A dataset to reuse the same chronological partition boundaries. It constructs 24-hour windows containing only the nine electrothermal variables. The measured force at \(t\) is retained separately for the persistence baseline; it is not included in the Formulation B input tensor.

Main output:

```text
resultats_scenario_B_electrothermique_t_plus_1h/jeu_donnees_scenario_B_complet_t_plus_1h.csv
```

The script also exports partition-specific CSV files, NPZ tensors, a persistence baseline, variable and sequence audits, descriptive statistics, correlations, figures, and a construction report.

### Step 02 — Train and compare Formulations A and B

```bash
python scripts/02_train_compare_architectures_scenarios_A_B_t_plus_1h.py
```

The script loads the prepared A and B datasets, checks their target timestamps and partition labels, and pairs both formulations on their common target timestamps. All seven architectures are trained and evaluated for each formulation.

Hyperparameters are selected using the validation partition. Scalers are fitted on training data during selection. The selected models are then refitted on the combined training and validation data, and the test partition is reserved for final evaluation.

Main outputs are saved in:

```text
resultats_comparaison_architectures_t_plus_1h/
```

These include model files, validation-search results, final test metrics, paired predictions, a timestamp-alignment audit, monthly test metrics, figures, and a summary report.

### Step 03 — Construct and evaluate Formulation C

```bash
python scripts/03_build_and_train_scenario_C_deltaF_t_plus_1h.py
```

This script obtains the electrothermal sequences from Formulation B and the measured current force \(F(t)\), target force \(F(t+1)\), and partition metadata from Formulation A. It pairs the datasets by target timestamp and retains observations for which the required current-force measurement is available.

It learns:

\[
\Delta F(t+1)=F(t+1)-F(t)
\]

and reconstructs:

\[
\widehat{F}(t+1)=F(t)+\widehat{\Delta F}(t+1).
\]

The measured \(F(t)\) is not included in the model input matrix \(X\). The implemented campaign restricts Formulation C to the common A/B timestamps; it does not implement the potentially larger independent C dataset discussed as future work.

Main outputs are saved in:

```text
resultats_scenario_C_variation_force_t_plus_1h/
```

These include the constructed C dataset, target metadata, model files, validation-search results, selected hyperparameters, test metrics for reconstructed force and predicted increments, persistence-baseline metrics, timestamped predictions, monthly metrics, figures, and a report.

## 6. Experimental protocol

The intended experimental protocol is:

- 24 consecutive hourly input observations, ending at time \(t\);
- one-hour prediction horizon, with target measured at exactly \(t+1\) h;
- chronological train/validation/test partitioning, with nominal fractions 70%/15%/15% in the initial preparation;
- no random shuffling of the chronological partitions;
- no interpolation or imputation of missing values in the sequence construction;
- hyperparameter selection on validation data;
- final refitting on training plus validation data;
- final test evaluation after model selection;
- paired A/B comparison on common target timestamps;
- a persistence baseline defined by \(\hat F(t+1)=F(t)\).

The feature scalers are fitted using training observations during model selection and refitted on training plus validation observations for the final model. Because input windows overlap, individual hourly values can occur in multiple training windows; the implemented scaler fitting procedure operates on the hourly rows obtained by reshaping the windowed training arrays.

The neural-network training uses AdamW, a learning rate of \(10^{-3}\), weight decay of \(10^{-4}\), batch size 128, a maximum of 100 epochs, early-stopping patience of 12 epochs during candidate selection, and gradient clipping with a maximum norm of 2.0. The base random seed is 42; the scripts apply additional candidate and final-training seeds as specified in their source code. Exact bitwise reproducibility is not guaranteed across different hardware, library builds, or execution environments.

## 7. Important interpretation notes

1. **Formulation C requires a current mechanical measurement.** It is not a sensorless method: the measured \(F(t)\) is needed to reconstruct the absolute force forecast.
2. **Formulation B estimates absolute force without a mechanical input.** The persistence baseline is computed separately and is not part of the B model features.
3. **The three-formulation comparison is exploratory.** Formulation C was developed after the A/B test results had been examined during the research process. Its hyperparameters were selected on validation, but the overall A/B/C comparison is not a fully untouched confirmatory comparison. Independent confirmation on a new test period or another transformer is needed.
4. **The dataset represents one transformer and one year.** External generalisation to other transformers, designs, cooling systems, and operating periods has not been established.
5. **Overlapping windows are not independent samples.** Test metrics describe the selected chronological interval and should not be interpreted as results from independent experimental trials.
6. **Prediction does not establish causality.** Statistical predictive relationships between electrothermal variables and force do not demonstrate a causal physical mechanism.
7. **Do not redistribute the original data or record-level derivatives without checking the data rights.** Refer to the original dataset record and its applicable terms.

## 8. Troubleshooting

- **`FileNotFoundError` for the source CSV:** verify that `Barug2025_sensordata.csv` is stored in `data/raw/` and that the filename matches the configuration in Step 00.
- **`FileNotFoundError` for a prepared dataset:** run the scripts in order (00, 01, 02, 03) and verify that each preceding step completed successfully.
- **Missing predictor columns:** inspect the source CSV headers and the audit reports. Update the explicit feature list only after confirming that the columns have the intended physical meaning and units.
- **XGBoost or PyTorch import errors:** activate the intended environment and install dependencies from `requirements.txt`, or recreate the Conda environment.
- **Different sample counts:** inspect the generated temporal-gap, missing-value, and A/B alignment reports. Do not force sample counts by interpolation or by silently changing the partitions.
- **Different numerical results:** record Python, package, operating-system, CPU/GPU, and random-seed information. Small numerical differences can arise across environments and hardware.

## 9. Citation

If you use this software package, cite the associated research article once its final bibliographic details are available. Also cite the original dataset:

Bærug, H., Madshaven, I., & Espedal, C. (2025). *Supporting data for thermomechanical modelling of clamping force in power transformer in operation*. Zenodo. https://doi.org/10.5281/zenodo.17223516

If this package is archived on Zenodo, replace this note with the software package's version-specific DOI and include that DOI in the manuscript's Code Availability statement.

## 10. License

The licence for the code in this repository should be stated in the accompanying `LICENSE` file and selected to reflect the author's intentions. The code licence does not grant rights to the original source dataset or to third-party material. The source dataset remains subject to its own rights and terms.
