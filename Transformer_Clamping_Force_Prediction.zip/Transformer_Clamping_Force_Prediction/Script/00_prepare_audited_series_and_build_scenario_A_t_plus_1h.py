# -*- coding: utf-8 -*-
"""
PREPARATION DU JEU DE DONNEES DYNAMIQUE - MODELESCENARIO A
Prediction de la force de serrage a t+1 heure a partir des donnees disponibles a t.

Ce script :
  1) lit un fichier original CSV / XLSX / XLS / Parquet ;
  2) identifie ou permet de configurer l'horodatage et la force de serrage ;
  3) audite les colonnes, les valeurs manquantes, les doublons et les pas temporels ;
  4) selectionne les variables numeriques thermiques/electriques (ou une liste manuelle) ;
  5) construit des sequences historiques de 24 heures sans interpolation ;
  6) cible exclusivement F(t+1h), sans utiliser de mesure apres t dans X ;
  7) cree des partitions chronologiques train / validation / test ;
  8) calcule le baseline de persistance F_hat(t+1)=F(t) ;
  9) exporte CSV, NPZ, tableaux d'audit, graphiques et rapport texte.

IMPORTANT :
- Le script n'entraine pas encore les architectures IA. Il prepare une base commune.
- Aucune interpolation temporelle n'est effectuee.
- Une observation n'est retenue que si les 24 heures d'entree sont presentes a chaque
  heure, si l'heure cible t+1 est presente exactement, et si toutes les entrees requises
  ainsi que la cible sont numeriques et disponibles.
- L'utilisateur doit verifier le fichier audit_colonnes.csv et le rapport avant de
  considerer la base comme valide scientifiquement.

Dependances : pandas, numpy, matplotlib, openpyxl (pour Excel).
Installation au besoin : pip install pandas numpy matplotlib openpyxl
"""


import os
import re
import json
import math
import warnings
from pathlib import Path
from datetime import timedelta

import numpy as np
import pandas as pd

# =============================================================================
# CONFIGURATION UTILISATEUR
# =============================================================================

# Répertoire racine du projet
PROJECT_DIR = Path(__file__).resolve().parent.parent

# Fichier original
INPUT_FILE = str(
    PROJECT_DIR / "data" / "raw" / "Barug2025_sensordata.csv"
)

# Feuille Excel
SHEET_NAME = None

# Identification des colonnes
TIME_COLUMN = "Timestamp"
DATE_COLUMN = None
TIME_OF_DAY_COLUMN = None
TARGET_COLUMN = "Clamping force [kN]"

# Les neuf variables électrothermiques retenues
FEATURE_COLUMNS = [
    "Voltage [kV]",
    "Current [A]",
    "Ambient [degC]",
    "Top oil [degC]",
    "Bottom oil [degC]",
    "Mid-spot HV [degC]",
    "Mid-spot LV [degC]",
    "Hot-spot HV [degC]",
    "Hot-spot LV [degC]",
]

EXCLUDE_COLUMNS = []

INCLUDE_PREVIOUS_FORCE = True
TARGET_SCALE_TO_KN = None

WINDOW_HOURS = 24
INTERVAL_HOURS = 1

TRAIN_FRACTION = 0.70
VALIDATION_FRACTION = 0.15
TEST_FRACTION = 0.15

AGGREGATE_DUPLICATE_TIMESTAMPS = True

# Dossier de sortie
OUTPUT_DIR = PROJECT_DIR / "resultats_prediction_t_plus_1h_modele_B"

CSV_ENCODINGS = ["utf-8-sig", "utf-8", "cp1252", "latin1"]

# Liste manuelle des variables d'entree, ou None pour selection automatique.
# Exemple : FEATURE_COLUMNS = ["Ambient temperature", "Top oil temperature", "Current"]
# Ne PAS mettre la force cible dans cette liste : le script l'ajoute comme historique
# (si INCLUDE_PREVIOUS_FORCE=True).
FEATURE_COLUMNS = None

# Colonnes a exclure explicitement, meme si elles semblent numeriques.
EXCLUDE_COLUMNS = []

# Inclure l'historique de la force mesuree jusqu'a t dans la sequence d'entree.
# Recommande : True. A t+1, F(t) est bien une information deja disponible.
INCLUDE_PREVIOUS_FORCE = True

# Facteur de conversion de la force source vers kN.
# None = detection d'apres le nom de la colonne ; sinon entrer 1.0 si deja en kN,
# 0.001 si en N, ou le facteur adapte a l'unite source.
TARGET_SCALE_TO_KN = None

WINDOW_HOURS = 24
INTERVAL_HOURS = 1
TRAIN_FRACTION = 0.70
VALIDATION_FRACTION = 0.15
TEST_FRACTION = 0.15

# Politique en cas de plusieurs mesures au meme horodatage : moyenne des colonnes numeriques.
# Les doublons sont d'abord exportes pour controle.
AGGREGATE_DUPLICATE_TIMESTAMPS = True


OUTPUT_DIR = PROJECT_DIR / "resultats_prediction_t_plus_1h_modele_B"

# Encodages essayes pour CSV.
CSV_ENCODINGS = ["utf-8-sig", "utf-8", "cp1252", "latin1"]

# =============================================================================
# OUTILS GENERAUX
# =============================================================================

SUPPORTED_EXTENSIONS = {".csv", ".txt", ".xlsx", ".xls", ".parquet", ".pq"}

THERMAL_ELECTRICAL_PATTERNS = [
    r"temp", r"temperature", r"therm", r"oil", r"hot.?spot", r"hotspot",
    r"mid.?spot", r"ambient", r"winding", r"current", r"voltage", r"tension",
    r"power", r"load", r"frequency", r"freq", r"ampere", r"\bamp\b",
    r"^i(?:_|\s|\[|$|\d)", r"^v(?:_|\s|\[|$|\d)", r"^u(?:_|\s|\[|$|\d)",
    r"^p(?:_|\s|\[|$|\d)", r"courant", r"tension", r"huile", r"ambiant",
]

BLOCKED_NAME_PATTERNS = [
    r"pressure", r"pression", r"clamping.?pressure", r"serrage.?pressure",
    r"^id$", r"index", r"unnamed", r"serial", r"sequence", r"counter",
    r"target", r"label", r"future", r"next", r"lead", r"t\+1",
    r"calculated", r"calcule", r"prediction", r"predicted",
]

FORCE_NAME_PATTERNS = [
    r"f.?clamp", r"clamp.?force", r"clamping.?force", r"force.?clamp",
    r"force.?serrage", r"serrage.?force", r"clamping force", r"force de serrage",
]


def normalize_name(value: object) -> str:
    s = str(value).strip().lower()
    s = s.replace("₂", "2").replace("²", "2")
    s = re.sub(r"[\[\](){}]", " ", s)
    s = re.sub(r"[_\-]+", " ", s)
    s = re.sub(r"\s+", " ", s)
    return s


def safe_float_series(series: pd.Series) -> pd.Series:
    """Conversion numerique tolerante aux espaces et virgules decimales."""
    if pd.api.types.is_numeric_dtype(series):
        return pd.to_numeric(series, errors="coerce")
    s = series.astype(str).str.strip()
    s = s.replace({"": np.nan, "nan": np.nan, "None": np.nan, "NA": np.nan, "N/A": np.nan})
    # Supprimer les espaces ordinaires et insécables ; virgule decimale -> point.
    s = s.str.replace("\u00a0", "", regex=False).str.replace(" ", "", regex=False)
    s = s.str.replace(",", ".", regex=False)
    return pd.to_numeric(s, errors="coerce")


def find_input_file() -> Path:
    candidate = INPUT_FILE.strip() if isinstance(INPUT_FILE, str) else ""
    if not candidate:
        candidate = input("Chemin complet du fichier original CSV/XLSX/Parquet : ").strip().strip('"')
    p = Path(candidate).expanduser()
    if p.is_dir():
        files = sorted([x for x in p.iterdir() if x.is_file() and x.suffix.lower() in SUPPORTED_EXTENSIONS])
        if not files:
            raise FileNotFoundError(f"Aucun fichier compatible trouve dans : {p}")
        print("\nFichiers compatibles trouves :")
        for i, f in enumerate(files, 1):
            print(f"  {i}. {f.name}")
        selection = input("Numero du fichier a utiliser : ").strip()
        try:
            p = files[int(selection) - 1]
        except Exception as exc:
            raise ValueError("Selection de fichier invalide.") from exc
    if not p.exists():
        raise FileNotFoundError(f"Fichier introuvable : {p}")
    if p.suffix.lower() not in SUPPORTED_EXTENSIONS:
        raise ValueError(f"Format non supporte : {p.suffix}. Formats : {sorted(SUPPORTED_EXTENSIONS)}")
    return p.resolve()


def read_source(path: Path) -> tuple[pd.DataFrame, str]:
    ext = path.suffix.lower()
    if ext in {".xlsx", ".xls"}:
        df = pd.read_excel(path, sheet_name=SHEET_NAME)
        if isinstance(df, dict):
            first_name = next(iter(df))
            print(f"Feuille Excel utilisee : {first_name}")
            df = df[first_name]
        sheet = SHEET_NAME if SHEET_NAME is not None else "premiere feuille"
        return df, f"Excel ({sheet})"
    if ext in {".parquet", ".pq"}:
        return pd.read_parquet(path), "Parquet"
    last_error = None
    for enc in CSV_ENCODINGS:
        try:
            # sep=None detecte generalement virgule, point-virgule ou tabulation.
            return pd.read_csv(path, sep=None, engine="python", encoding=enc), f"CSV (encodage {enc})"
        except Exception as exc:
            last_error = exc
    raise RuntimeError(f"Impossible de lire le CSV. Derniere erreur : {last_error}")


def detect_datetime(df: pd.DataFrame) -> tuple[pd.Series, str, list[str]]:
    """Retourne l'horodatage et les colonnes de temps a exclure des entrees."""
    if TIME_COLUMN is not None:
        if TIME_COLUMN not in df.columns:
            raise KeyError(f"TIME_COLUMN='{TIME_COLUMN}' absent. Colonnes : {list(df.columns)}")
        ts = pd.to_datetime(df[TIME_COLUMN], errors="coerce", dayfirst=False)
        if ts.notna().mean() < 0.80:
            raise ValueError(f"Moins de 80% des valeurs de {TIME_COLUMN} sont des dates/heures valides.")
        return ts, str(TIME_COLUMN), [str(TIME_COLUMN)]

    if DATE_COLUMN is not None:
        if DATE_COLUMN not in df.columns:
            raise KeyError(f"DATE_COLUMN='{DATE_COLUMN}' absent.")
        date_part = df[DATE_COLUMN].astype(str).str.strip()
        time_cols = [str(DATE_COLUMN)]
        if TIME_OF_DAY_COLUMN is not None:
            if TIME_OF_DAY_COLUMN not in df.columns:
                raise KeyError(f"TIME_OF_DAY_COLUMN='{TIME_OF_DAY_COLUMN}' absent.")
            tcol = df[TIME_OF_DAY_COLUMN]
            if pd.api.types.is_numeric_dtype(tcol) and tcol.dropna().between(0, 23).all():
                time_part = tcol.map(lambda x: f"{int(x):02d}:00:00" if pd.notna(x) else "")
            else:
                time_part = tcol.astype(str).str.strip()
            combined = date_part + " " + time_part
            time_cols.append(str(TIME_OF_DAY_COLUMN))
        else:
            combined = date_part
        ts = pd.to_datetime(combined, errors="coerce", dayfirst=True)
        if ts.notna().mean() < 0.80:
            raise ValueError("DATE_COLUMN/TIME_OF_DAY_COLUMN n'a pas pu etre converti correctement.")
        return ts, " + ".join(time_cols), time_cols

    # Reperer les colonnes date et heure distinctes AVANT de tester une colonne
    # nommee simplement 'Date' : sinon l'heure de la journee pourrait etre perdue.
    date_candidates, time_candidates = [], []
    for c in df.columns:
        n = normalize_name(c)
        if re.search(r"\bdate\b|day", n):
            date_candidates.append(c)
        if re.search(r"\btime\b|\bhour\b|\bheure\b", n):
            time_candidates.append(c)

    for dc in date_candidates:
        for tc in time_candidates:
            if dc == tc:
                continue
            tcol = df[tc]
            if pd.api.types.is_numeric_dtype(tcol) and tcol.dropna().between(0, 23).all():
                time_part = tcol.map(lambda x: f"{int(x):02d}:00:00" if pd.notna(x) else "")
            else:
                time_part = tcol.astype(str).str.strip()
            combined = df[dc].astype(str).str.strip() + " " + time_part
            parsed = pd.to_datetime(combined, errors="coerce", dayfirst=True)
            if parsed.notna().mean() >= 0.80:
                return parsed, f"{dc} + {tc}", [str(dc), str(tc)]

    # Colonnes pouvant porter un timestamp complet : Timestamp, DateTime, etc.
    candidates = []
    for c in df.columns:
        n = normalize_name(c)
        if any(k in n for k in ["timestamp", "datetime", "date time", "measurement time", "date heure"]):
            candidates.append(c)
    # Une colonne nommee 'Time' peut contenir un timestamp complet.
    for c in df.columns:
        n = normalize_name(c)
        if "time" in n and c not in candidates and c not in time_candidates:
            candidates.append(c)
    best = None
    best_score = 0
    for c in candidates:
        parsed = pd.to_datetime(df[c], errors="coerce", dayfirst=False)
        score = float(parsed.notna().mean())
        if score > best_score:
            best, best_score = (c, parsed), score
    if best is not None and best_score >= 0.80:
        c, parsed = best
        return parsed, str(c), [str(c)]

    # En dernier recours, une colonne Date seule (horaires a minuit).
    for c in date_candidates:
        parsed = pd.to_datetime(df[c], errors="coerce", dayfirst=True)
        if parsed.notna().mean() >= 0.80:
            return parsed, str(c), [str(c)]

    examples = {str(c): df[c].head(3).astype(str).tolist() for c in df.columns[:min(12, len(df.columns))]}
    raise ValueError(
        "Horodatage non identifie automatiquement. Renseigner TIME_COLUMN ou DATE_COLUMN "
        "(et TIME_OF_DAY_COLUMN si necessaire) dans la configuration.\n"
        f"Exemples de colonnes : {examples}"
    )


def detect_target(df: pd.DataFrame) -> str:
    if TARGET_COLUMN is not None:
        if TARGET_COLUMN not in df.columns:
            raise KeyError(f"TARGET_COLUMN='{TARGET_COLUMN}' absent. Colonnes : {list(df.columns)}")
        return str(TARGET_COLUMN)
    scored = []
    for c in df.columns:
        n = normalize_name(c)
        score = sum(1 for pat in FORCE_NAME_PATTERNS if re.search(pat, n))
        if score:
            scored.append((score, c))
    if not scored:
        likely = [str(c) for c in df.columns if "force" in normalize_name(c) or "clamp" in normalize_name(c) or "serrage" in normalize_name(c)]
        raise ValueError(
            "Colonne de force de serrage non identifiee automatiquement. "
            "Renseigner TARGET_COLUMN dans la configuration. "
            f"Colonnes pouvant etre pertinentes : {likely}"
        )
    scored.sort(key=lambda x: x[0], reverse=True)
    if len(scored) > 1 and scored[0][0] == scored[1][0]:
        print("Plusieurs colonnes de force possibles :", [str(x[1]) for x in scored])
        raise ValueError("Detection de la cible ambigue. Renseigner TARGET_COLUMN dans la configuration.")
    return str(scored[0][1])


def select_predictors(df: pd.DataFrame, timestamp_cols: list[str], target_col: str) -> tuple[list[str], list[str]]:
    if FEATURE_COLUMNS is not None:
        missing = [c for c in FEATURE_COLUMNS if c not in df.columns]
        if missing:
            raise KeyError(f"FEATURE_COLUMNS absentes : {missing}")
        selected = [str(c) for c in FEATURE_COLUMNS]
        forbidden = []
        for c in selected:
            n = normalize_name(c)
            if c in timestamp_cols:
                forbidden.append(c)
            if c == target_col or any(k in n for k in ["pressure", "pression", "clamping force", "force de serrage"]):
                forbidden.append(c)
            if any(re.search(p, n) for p in [r"target", r"future", r"next", r"lead", r"t\+1"]):
                forbidden.append(c)
        if forbidden:
            raise ValueError(f"FEATURE_COLUMNS contient des variables interdites ou a risque de fuite : {sorted(set(forbidden))}")
        return selected, []

    selected, excluded = [], []
    manual_exclusions = {normalize_name(c) for c in EXCLUDE_COLUMNS}
    timestamp_set = set(timestamp_cols)
    for c in df.columns:
        cs = str(c)
        n = normalize_name(c)
        if cs in timestamp_set or cs == target_col:
            continue
        if n in manual_exclusions:
            excluded.append(cs)
            continue
        if any(re.search(p, n) for p in BLOCKED_NAME_PATTERNS):
            excluded.append(cs)
            continue
        # Exclure toutes les autres variables de force / pression pour eviter fuite ou doublon.
        if any(k in n for k in ["force", "clamp", "serrage", "pressure", "pression"]):
            excluded.append(cs)
            continue
        numeric = safe_float_series(df[c])
        numeric_ratio = float(numeric.notna().mean())
        if numeric_ratio < 0.70:
            excluded.append(cs)
            continue
        matched = any(re.search(p, n) for p in THERMAL_ELECTRICAL_PATTERNS)
        if matched:
            selected.append(cs)
        else:
            excluded.append(cs)

    # Repli uniquement si aucune variable nommee thermique/electrique n'a ete trouvee.
    # Dans ce cas, garder les colonnes numeriques non bloquees, mais le signaler.
    if not selected:
        print("AVERTISSEMENT : aucune variable detectee par les noms. Repli vers toutes les colonnes numeriques admissibles.")
        for c in df.columns:
            cs, n = str(c), normalize_name(c)
            if cs in timestamp_set or cs == target_col or cs in excluded:
                continue
            if any(k in n for k in ["force", "clamp", "serrage", "pressure", "pression", "id", "index"]):
                continue
            numeric_ratio = float(safe_float_series(df[c]).notna().mean())
            if numeric_ratio >= 0.70:
                selected.append(cs)
    return selected, excluded


def infer_force_scale_to_kn(target_col: str) -> tuple[float, str]:
    if TARGET_SCALE_TO_KN is not None:
        return float(TARGET_SCALE_TO_KN), "facteur configure par l'utilisateur"
    n = normalize_name(target_col)
    if "kn" in n or "kilonewton" in n:
        return 1.0, "unite kN detectee dans le nom"
    # Eviter de traiter kN comme N : le test kN est fait ci-dessus.
    if re.search(r"\(\s*n\s*\)|\[\s*n\s*\]|_n$| force n\b|newton", n):
        return 0.001, "unite N detectee dans le nom"
    return 1.0, "unite non explicite : valeur conservee comme kN par convention provisoire ; verifier"


def regression_metrics(y_true: np.ndarray, y_pred: np.ndarray) -> dict:
    y_true = np.asarray(y_true, dtype=float)
    y_pred = np.asarray(y_pred, dtype=float)
    mask = np.isfinite(y_true) & np.isfinite(y_pred)
    yt, yp = y_true[mask], y_pred[mask]
    if len(yt) == 0:
        return {"n": 0, "MAE_kN": np.nan, "RMSE_kN": np.nan, "R2": np.nan}
    mae = float(np.mean(np.abs(yt - yp)))
    rmse = float(np.sqrt(np.mean((yt - yp) ** 2)))
    denom = float(np.sum((yt - np.mean(yt)) ** 2))
    r2 = float(1 - np.sum((yt - yp) ** 2) / denom) if denom > 0 else np.nan
    return {"n": int(len(yt)), "MAE_kN": mae, "RMSE_kN": rmse, "R2": r2}


def write_csv(df: pd.DataFrame, path: Path) -> None:
    df.to_csv(path, index=False, encoding="utf-8-sig")


def main() -> None:
    warnings.filterwarnings("ignore", category=UserWarning)
    source_path = find_input_file()
    print(f"\nFichier source : {source_path}")
    raw, source_format = read_source(source_path)
    raw.columns = [str(c).strip() for c in raw.columns]
    if raw.empty:
        raise ValueError("Le fichier source est vide.")

    output_dir = Path(OUTPUT_DIR).expanduser() if OUTPUT_DIR else source_path.parent / "resultats_prediction_t_plus_1h_modele_B"
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "graphiques").mkdir(exist_ok=True)

    # Rapport initial et profil des colonnes avant transformation.
    n_raw = len(raw)
    raw_missing = pd.DataFrame({
        "colonne": raw.columns,
        "type_source": [str(raw[c].dtype) for c in raw.columns],
        "valeurs_non_vides": [int(raw[c].notna().sum()) for c in raw.columns],
        "valeurs_manquantes": [int(raw[c].isna().sum()) for c in raw.columns],
        "pourcentage_manquant": [float(raw[c].isna().mean() * 100) for c in raw.columns],
        "exemples": [" | ".join(raw[c].dropna().astype(str).head(3).tolist()) for c in raw.columns],
    })
    write_csv(raw_missing, output_dir / "audit_colonnes_brut.csv")

    timestamp, timestamp_description, timestamp_cols = detect_datetime(raw)
    target_col = detect_target(raw)
    predictor_cols, auto_excluded = select_predictors(raw, timestamp_cols, target_col)
    if not predictor_cols:
        raise ValueError("Aucune variable explicative admissible trouvee. Renseigner FEATURE_COLUMNS.")

    # Conversion numerique des variables explicatives et de la cible.
    df = raw.copy()
    df["__timestamp__"] = pd.to_datetime(timestamp, errors="coerce")
    df["__force_source_numeric__"] = safe_float_series(df[target_col])
    force_scale, scale_reason = infer_force_scale_to_kn(target_col)
    df["F_clamp_kN"] = df["__force_source_numeric__"] * force_scale
    for c in predictor_cols:
        df[c] = safe_float_series(df[c])

    invalid_time_count = int(df["__timestamp__"].isna().sum())
    df = df.loc[df["__timestamp__"].notna()].copy()
    df = df.sort_values("__timestamp__").reset_index(drop=True)

    # Doublons d'horodatage : export avant tout regroupement.
    duplicate_mask = df["__timestamp__"].duplicated(keep=False)
    duplicates = df.loc[duplicate_mask].copy()
    if not duplicates.empty:
        dup_report = duplicates.groupby("__timestamp__", as_index=False).size().rename(columns={"size": "nombre_lignes"})
        write_csv(dup_report, output_dir / "horodatages_dupliques.csv")
        if not AGGREGATE_DUPLICATE_TIMESTAMPS:
            raise ValueError("Des horodatages dupliques existent et AGGREGATE_DUPLICATE_TIMESTAMPS=False.")
        # Agregation numerique par moyenne pour les colonnes analysees ; autres champs exclus.
        keep_cols = ["F_clamp_kN"] + predictor_cols
        df = df.groupby("__timestamp__", as_index=False)[keep_cols].mean()
        duplicate_action = "doublons agreges par moyenne sur les variables utilisees"
    else:
        duplicate_action = "aucun doublon"
        df = df[["__timestamp__", "F_clamp_kN"] + predictor_cols].copy()

    df = df.sort_values("__timestamp__").reset_index(drop=True)
    df = df.rename(columns={"__timestamp__": "timestamp"})

    # Audit des pas temporels apres traitement des doublons.
    deltas = df["timestamp"].diff().dropna()
    expected_delta = pd.Timedelta(hours=INTERVAL_HOURS)
    exact_hour_count = int((deltas == expected_delta).sum())
    gap_rows = []
    for i in range(1, len(df)):
        delta = df.loc[i, "timestamp"] - df.loc[i - 1, "timestamp"]
        if delta != expected_delta:
            gap_rows.append({
                "timestamp_precedent": df.loc[i - 1, "timestamp"],
                "timestamp_suivant": df.loc[i, "timestamp"],
                "ecart_heures": delta.total_seconds() / 3600.0,
                "heures_manquantes_estimees": max(int(round(delta.total_seconds() / 3600.0)) - 1, 0),
            })
    gaps_df = pd.DataFrame(gap_rows)
    if not gaps_df.empty:
        write_csv(gaps_df, output_dir / "ruptures_temporelles.csv")

    # Profil des valeurs manquantes apres conversion numerique.
    used_cols = predictor_cols + ["F_clamp_kN"]
    miss_rows = []
    for c in used_cols:
        miss_rows.append({
            "variable": c,
            "valeurs_manquantes": int(df[c].isna().sum()),
            "pourcentage_manquant": float(df[c].isna().mean() * 100),
            "min": float(df[c].min()) if df[c].notna().any() else np.nan,
            "max": float(df[c].max()) if df[c].notna().any() else np.nan,
            "moyenne": float(df[c].mean()) if df[c].notna().any() else np.nan,
            "ecart_type": float(df[c].std()) if df[c].notna().sum() > 1 else np.nan,
        })
    missing_df = pd.DataFrame(miss_rows)
    write_csv(missing_df, output_dir / "audit_valeurs_manquantes_et_statistiques.csv")

    # Signalement exploratoire des valeurs extremes par la regle 1.5*IQR.
    # Ces valeurs ne sont PAS supprimees automatiquement.
    outlier_rows = []
    for c in used_cols:
        s = df[c].dropna().astype(float)
        if len(s) >= 4:
            q1, q3 = float(s.quantile(0.25)), float(s.quantile(0.75))
            iqr = q3 - q1
            low, high = q1 - 1.5 * iqr, q3 + 1.5 * iqr
            n_out = int(((s < low) | (s > high)).sum())
        else:
            q1 = q3 = iqr = low = high = np.nan
            n_out = 0
        outlier_rows.append({
            "variable": c, "Q1": q1, "Q3": q3, "IQR": iqr,
            "borne_basse_1_5IQR": low, "borne_haute_1_5IQR": high,
            "nombre_valeurs_extremes": n_out,
            "pourcentage_valeurs_extremes": (100.0 * n_out / len(s)) if len(s) else np.nan,
            "action": "signalees uniquement ; aucune suppression automatique",
        })
    outlier_df = pd.DataFrame(outlier_rows)
    write_csv(outlier_df, output_dir / "audit_valeurs_extremes_IQR.csv")

    # Liste finale des variables dans l'ordre utilise.
    input_features = list(predictor_cols)
    if INCLUDE_PREVIOUS_FORCE:
        input_features.append("F_clamp_kN_history")
        df["F_clamp_kN_history"] = df["F_clamp_kN"]

    # Serie horaire auditee, avant creation des fenetres.
    write_csv(df[["timestamp", "F_clamp_kN"] + predictor_cols].copy(), output_dir / "serie_horaire_auditee.csv")

    # Construction des sequences. Aucune interpolation/remplissage n'est applique.
    values = df[input_features].to_numpy(dtype=float)
    force_values = df["F_clamp_kN"].to_numpy(dtype=float)
    timestamps = pd.to_datetime(df["timestamp"]).to_numpy()
    seq_list, y_list, base_list = [], [], []
    input_end_list, target_time_list = [], []
    rejected_gap = rejected_missing_input = rejected_missing_target = 0
    window = int(WINDOW_HOURS)
    if window < 1:
        raise ValueError("WINDOW_HOURS doit etre >= 1.")

    for end_idx in range(window - 1, len(df) - 1):
        start_idx = end_idx - window + 1
        expected_hist = pd.date_range(
            start=pd.Timestamp(timestamps[end_idx]) - pd.Timedelta(hours=window - 1),
            periods=window,
            freq=f"{INTERVAL_HOURS}h",
        )
        actual_hist = pd.DatetimeIndex(timestamps[start_idx:end_idx + 1])
        target_timestamp = pd.Timestamp(timestamps[end_idx]) + expected_delta
        if not actual_hist.equals(expected_hist) or pd.Timestamp(timestamps[end_idx + 1]) != target_timestamp:
            rejected_gap += 1
            continue
        seq = values[start_idx:end_idx + 1, :]
        y = force_values[end_idx + 1]
        if not np.isfinite(seq).all():
            rejected_missing_input += 1
            continue
        if not np.isfinite(y):
            rejected_missing_target += 1
            continue
        seq_list.append(seq.astype(np.float32))
        y_list.append(float(y))
        base_list.append(float(force_values[end_idx]))
        input_end_list.append(pd.Timestamp(timestamps[end_idx]))
        target_time_list.append(pd.Timestamp(timestamps[end_idx + 1]))

    if not seq_list:
        raise ValueError(
            "Aucune sequence valide n'a ete construite. Verifier les horodatages, "
            "les colonnes numeriques et les valeurs manquantes."
        )

    X_seq = np.stack(seq_list, axis=0)
    y = np.asarray(y_list, dtype=np.float32)
    y_persistence = np.asarray(base_list, dtype=np.float32)
    input_end = pd.to_datetime(pd.Series(input_end_list))
    target_time = pd.to_datetime(pd.Series(target_time_list))
    n_samples = len(y)

    # Separation chronologique par date cible (aucun melange aleatoire).
    if not math.isclose(TRAIN_FRACTION + VALIDATION_FRACTION + TEST_FRACTION, 1.0, abs_tol=1e-8):
        raise ValueError("Les fractions train/validation/test doivent totaliser 1.0.")
    n_train = int(np.floor(n_samples * TRAIN_FRACTION))
    n_val = int(np.floor(n_samples * VALIDATION_FRACTION))
    n_test = n_samples - n_train - n_val
    if min(n_train, n_val, n_test) <= 0:
        raise ValueError("Pas assez d'echantillons pour creer les trois partitions.")
    split_labels = np.array(["train"] * n_train + ["validation"] * n_val + ["test"] * n_test)
    indices = {
        "train": np.arange(0, n_train),
        "validation": np.arange(n_train, n_train + n_val),
        "test": np.arange(n_train + n_val, n_samples),
    }

    # Matrice aplatie commune aux modeles tabulaires et matrice sequentielle pour LSTM/GRU.
    flat_names = []
    for lag in range(window - 1, -1, -1):
        for feature in input_features:
            flat_names.append(f"{feature}__lag_{lag}h")
    X_flat = X_seq.reshape(n_samples, window * len(input_features)).astype(np.float32)

    base_dataset = pd.DataFrame({
        "input_end_time_t": input_end,
        "target_time_t_plus_1h": target_time,
        "F_t_kN_baseline": y_persistence,
        "F_target_t_plus_1h_kN": y,
        "partition": split_labels,
    })
    flat_df = pd.DataFrame(X_flat, columns=flat_names)
    full_flat = pd.concat([base_dataset.reset_index(drop=True), flat_df], axis=1)

    # Exports principaux.
    write_csv(full_flat, output_dir / "jeu_donnees_dynamique_complet_t_plus_1h.csv")
    for split, idx in indices.items():
        write_csv(full_flat.iloc[idx].reset_index(drop=True), output_dir / f"jeu_donnees_{split}_t_plus_1h.csv")

    npz_payload = {
        "X_train_sequence": X_seq[indices["train"]],
        "X_validation_sequence": X_seq[indices["validation"]],
        "X_test_sequence": X_seq[indices["test"]],
        "X_train_flat": X_flat[indices["train"]],
        "X_validation_flat": X_flat[indices["validation"]],
        "X_test_flat": X_flat[indices["test"]],
        "y_train": y[indices["train"]],
        "y_validation": y[indices["validation"]],
        "y_test": y[indices["test"]],
        "F_t_train_persistence": y_persistence[indices["train"]],
        "F_t_validation_persistence": y_persistence[indices["validation"]],
        "F_t_test_persistence": y_persistence[indices["test"]],
        "input_end_time_train": input_end.iloc[indices["train"]].astype(str).to_numpy(),
        "input_end_time_validation": input_end.iloc[indices["validation"]].astype(str).to_numpy(),
        "input_end_time_test": input_end.iloc[indices["test"]].astype(str).to_numpy(),
        "target_time_train": target_time.iloc[indices["train"]].astype(str).to_numpy(),
        "target_time_validation": target_time.iloc[indices["validation"]].astype(str).to_numpy(),
        "target_time_test": target_time.iloc[indices["test"]].astype(str).to_numpy(),
        "sequence_feature_names": np.asarray(input_features, dtype=str),
        "flat_feature_names": np.asarray(flat_names, dtype=str),
        "window_hours": np.asarray([window], dtype=np.int32),
    }
    np.savez_compressed(output_dir / "jeu_donnees_dynamique_t_plus_1h.npz", **npz_payload)

    # Baseline persistance sur chaque partition.
    baseline_rows = []
    for split, idx in indices.items():
        m = regression_metrics(y[idx], y_persistence[idx])
        baseline_rows.append({"partition": split, **m,
                              "date_cible_debut": str(target_time.iloc[idx[0]]),
                              "date_cible_fin": str(target_time.iloc[idx[-1]])})
    baseline_df = pd.DataFrame(baseline_rows)
    write_csv(baseline_df, output_dir / "baseline_persistance_F_t_vers_F_t_plus_1.csv")

    # Correlations descriptives entre X au temps t (derniere ligne de sequence) et cible.
    corr_rows = []
    last_step = X_seq[:, -1, :]
    for j, feature in enumerate(input_features):
        xj = last_step[:, j]
        if np.std(xj) > 0 and np.std(y) > 0:
            corr = float(np.corrcoef(xj, y)[0, 1])
        else:
            corr = np.nan
        corr_rows.append({"variable_a_t": feature, "correlation_pearson_avec_F_t_plus_1": corr})
    corr_df = pd.DataFrame(corr_rows).sort_values("correlation_pearson_avec_F_t_plus_1", key=lambda s: s.abs(), ascending=False)
    write_csv(corr_df, output_dir / "correlations_variables_t_et_cible_t_plus_1.csv")

    # Audit lisible de la selection des variables.
    selection_rows = []
    for c in predictor_cols:
        selection_rows.append({"colonne_source": c, "statut": "entree selectionnee", "raison": "variable numerique detectee/configuree"})
    if INCLUDE_PREVIOUS_FORCE:
        selection_rows.append({"colonne_source": target_col, "statut": "historique autorise", "raison": "force mesuree jusqu'a t uniquement ; cible a t+1"})
    for c in auto_excluded:
        selection_rows.append({"colonne_source": c, "statut": "exclue", "raison": "non numerique, nom non thermique/electrique ou motif d'exclusion"})
    write_csv(pd.DataFrame(selection_rows), output_dir / "audit_selection_variables.csv")

    split_rows = []
    for split, idx in indices.items():
        split_rows.append({
            "partition": split,
            "n_observations": len(idx),
            "proportion": len(idx) / n_samples,
            "premiere_heure_entree_t": str(input_end.iloc[idx[0]]),
            "derniere_heure_entree_t": str(input_end.iloc[idx[-1]]),
            "premiere_cible_t_plus_1": str(target_time.iloc[idx[0]]),
            "derniere_cible_t_plus_1": str(target_time.iloc[idx[-1]]),
        })
    split_df = pd.DataFrame(split_rows)
    write_csv(split_df, output_dir / "resume_partitions_chronologiques.csv")

    # Graphiques facultatifs mais utiles pour verifier les donnees.
    graph_status = []
    try:
        import matplotlib.pyplot as plt
        # Force originale dans le temps.
        fig, ax = plt.subplots(figsize=(13, 5))
        ax.plot(df["timestamp"], df["F_clamp_kN"], linewidth=0.8)
        ax.set_title("Force de serrage mesuree - serie originale")
        ax.set_xlabel("Temps")
        ax.set_ylabel("Force (kN)")
        ax.grid(True, alpha=0.3)
        fig.tight_layout()
        fig.savefig(output_dir / "graphiques" / "force_serrage_serie_originale.png", dpi=150)
        plt.close(fig)

        # Disponibilite des variables utilisees.
        fig, ax = plt.subplots(figsize=(11, max(4, 0.35 * len(missing_df))))
        plot_df = missing_df.sort_values("pourcentage_manquant", ascending=True)
        ax.barh(plot_df["variable"].astype(str), plot_df["pourcentage_manquant"])
        ax.set_xlabel("Valeurs manquantes (%)")
        ax.set_title("Taux de valeurs manquantes des variables utilisees")
        ax.grid(True, axis="x", alpha=0.3)
        fig.tight_layout()
        fig.savefig(output_dir / "graphiques" / "valeurs_manquantes_variables.png", dpi=150)
        plt.close(fig)

        # Cible et baseline de persistance sur les donnees echantillonnees.
        fig, ax = plt.subplots(figsize=(13, 5))
        ax.plot(target_time, y, label="Force cible F(t+1)", linewidth=0.9)
        ax.plot(target_time, y_persistence, label="Persistance F(t)", linewidth=0.8, alpha=0.8)
        ax.set_title("Cible a t+1h et baseline de persistance")
        ax.set_xlabel("Heure cible")
        ax.set_ylabel("Force (kN)")
        ax.legend()
        ax.grid(True, alpha=0.3)
        fig.tight_layout()
        fig.savefig(output_dir / "graphiques" / "cible_et_persistance.png", dpi=150)
        plt.close(fig)
        graph_status.append("graphiques crees")
    except Exception as exc:
        graph_status.append(f"graphiques non crees : {exc}")

    # Rapport texte synthese.
    start_time = df["timestamp"].min()
    end_time = df["timestamp"].max()
    total_possible = max(len(df) - (window), 0)
    accepted_pct = 100 * n_samples / total_possible if total_possible else np.nan
    report = []
    report += [
        "RAPPORT - PREPARATION DU MODELE DYNAMIQUE B : PREDICTION A t+1 HEURE",
        "=" * 76,
        f"Fichier source : {source_path}",
        f"Format lu : {source_format}",
        f"Nombre de lignes source : {n_raw}",
        f"Nombre de lignes avec horodatage valide : {len(df)}",
        f"Lignes avec horodatage invalide supprimees : {invalid_time_count}",
        f"Colonne(s) temporelle(s) : {timestamp_description}",
        f"Colonne cible force : {target_col}",
        f"Conversion vers kN : facteur {force_scale} ({scale_reason})",
        f"Periode couverte apres traitement : {start_time} -> {end_time}",
        f"Doublons : {duplicate_action}",
        f"Nombre de ruptures d'une heure : {len(gaps_df)}",
        f"Intervalles exactement d'une heure : {exact_hour_count} sur {len(deltas)}",
        "",
        "DEFINITION DE LA TACHE",
        f"Fenetre historique : {window} observations horaires consecutives (t-{window-1}h a t)",
        "Cible : force mesuree exactement a t+1h",
        "Entrees : variables mesurees a t ou avant ; aucune interpolation n'est faite.",
        f"Historique de la force inclus : {INCLUDE_PREVIOUS_FORCE}",
        "Pression de serrage exclue automatiquement des predicteurs.",
        "",
        "VARIABLES D'ENTREE",
        *[f"- {c}" for c in input_features],
        "",
        "CONSTRUCTION DES ECHANTILLONS",
        f"Echantillons valides : {n_samples}",
        f"Echantillons possibles avant controles (approx.) : {total_possible}",
        f"Pourcentage retenu : {accepted_pct:.2f}%" if np.isfinite(accepted_pct) else "Pourcentage retenu : non calculable",
        f"Rejetes pour rupture temporelle : {rejected_gap}",
        f"Rejetes pour entree manquante/non numerique : {rejected_missing_input}",
        f"Rejetes pour cible manquante/non numerique : {rejected_missing_target}",
        "Aucune valeur manquante n'a ete imputée ou interpolee.",
        "",
        "PARTITIONS CHRONOLOGIQUES",
    ]
    for _, r in split_df.iterrows():
        report.append(
            f"{r['partition']}: n={int(r['n_observations'])}, "
            f"cibles {r['premiere_cible_t_plus_1']} -> {r['derniere_cible_t_plus_1']}"
        )
    report += ["", "BASELINE DE PERSISTANCE : prediction F(t+1)=F(t)"]
    for _, r in baseline_df.iterrows():
        report.append(
            f"{r['partition']}: RMSE={r['RMSE_kN']:.6f} kN ; "
            f"MAE={r['MAE_kN']:.6f} kN ; R2={r['R2']:.6f} ; n={int(r['n'])}"
        )
    report += [
        "",
        "AVERTISSEMENTS ET VERIFICATIONS AVANT ENTRAINEMENT",
        "1. Verifier audit_colonnes_brut.csv pour confirmer les noms et le sens physique des variables.",
        "2. Verifier audit_selection_variables.csv : la selection automatique doit etre validee physiquement.",
        "3. Verifier audit_valeurs_extremes_IQR.csv : les valeurs extremes sont signalees, jamais supprimees automatiquement.",
        "4. Verifier l'unite de la force. Si elle n'est pas en kN, regler TARGET_SCALE_TO_KN.",
        "5. Verifier que les variables d'entree sont bien disponibles a l'instant t en exploitation.",
        "6. La validation et le test sont chronologiques ; le test ne doit pas servir a choisir les hyperparametres.",
        "7. Les fenetres se chevauchent dans le temps, ce qui est normal pour une prediction glissante.",
        "8. Les resultats du baseline ne constituent pas encore une evaluation de modele IA.",
        "9. Une correlation n'implique pas une relation causale.",
        "",
        "FICHIERS PRINCIPAUX PRODUITS",
        "- serie_horaire_auditee.csv (serie chronologique apres audit, sans interpolation)",
        "- jeu_donnees_dynamique_complet_t_plus_1h.csv",
        "- jeu_donnees_train_t_plus_1h.csv / jeu_donnees_validation_t_plus_1h.csv / jeu_donnees_test_t_plus_1h.csv",
        "- jeu_donnees_dynamique_t_plus_1h.npz (tenseurs sequentiels et matrices aplaties)",
        "- baseline_persistance_F_t_vers_F_t_plus_1.csv",
        "- audit_colonnes_brut.csv, audit_valeurs_manquantes_et_statistiques.csv, audit_valeurs_extremes_IQR.csv, audit_selection_variables.csv",
        "- resume_partitions_chronologiques.csv, correlations_variables_t_et_cible_t_plus_1.csv",
        "- ruptures_temporelles.csv et horodatages_dupliques.csv si necessaire",
        "- graphiques/",
        "",
        "Statut graphiques : " + "; ".join(graph_status),
        "FIN DU RAPPORT",
    ]
    (output_dir / "RAPPORT_PREPARATION_DYNAMIQUE_t_plus_1h.txt").write_text("\n".join(report), encoding="utf-8")

    metadata = {
        "source_file": str(source_path),
        "source_format": source_format,
        "source_rows": int(n_raw),
        "rows_after_timestamp_and_duplicate_processing": int(len(df)),
        "timestamp_description": timestamp_description,
        "target_column_source": target_col,
        "target_output": "F_clamp_kN",
        "force_scale_to_kN": float(force_scale),
        "force_scale_reason": scale_reason,
        "predictor_columns_source": predictor_cols,
        "input_feature_names_including_force_history": input_features,
        "window_hours": int(window),
        "prediction_horizon_hours": int(INTERVAL_HOURS),
        "target_definition": "F(t+1h)",
        "input_definition": "sequence from t-(window-1)h to t inclusive",
        "no_interpolation": True,
        "include_previous_force": bool(INCLUDE_PREVIOUS_FORCE),
        "train_fraction": TRAIN_FRACTION,
        "validation_fraction": VALIDATION_FRACTION,
        "test_fraction": TEST_FRACTION,
        "n_samples": int(n_samples),
        "n_train": int(n_train),
        "n_validation": int(n_val),
        "n_test": int(n_test),
        "array_shape_sequence": list(X_seq.shape),
        "array_shape_flat": list(X_flat.shape),
        "duplicate_policy": duplicate_action,
        "rejected_gap": int(rejected_gap),
        "rejected_missing_input": int(rejected_missing_input),
        "rejected_missing_target": int(rejected_missing_target),
    }
    (output_dir / "metadata_experimentale.json").write_text(json.dumps(metadata, indent=2, ensure_ascii=False), encoding="utf-8")

    print("\n" + "=" * 72)
    print("PREPARATION TERMINEE")
    print("=" * 72)
    print(f"Dossier des resultats : {output_dir}")
    print(f"Echantillons valides : {n_samples} | train={n_train} | validation={n_val} | test={n_test}")
    print(f"Variables par heure : {len(input_features)} | fenetre : {window} h")
    print("\nBaseline persistance :")
    print(baseline_df.to_string(index=False))
    print("\nIMPORTANT : ouvre d'abord RAPPORT_PREPARATION_DYNAMIQUE_t_plus_1h.txt, puis verifie les fichiers d'audit.")
    print("Ne lance pas encore les architectures si une variable, une unite ou une colonne cible est mal identifiee.")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print("\nERREUR :", exc)
        print("Consulte la section CONFIGURATION UTILISATEUR au debut du script.")
        raise
