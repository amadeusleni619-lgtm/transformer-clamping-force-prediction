# -*- coding: utf-8 -*-
"""
Created on Sun Nov  1 23:04:51 2026

@author: Leni
"""

# -*- coding: utf-8 -*-
"""
COMPARAISON D'ARCHITECTURES POUR LA PREDICTION DE LA FORCE DE SERRAGE A t+1 HEURE

Scenarios :
  A : 9 variables electrothermiques + historique de la force (24 h)
  B : 9 variables electrothermiques seulement (24 h)

Architectures : Ridge, Random Forest, XGBoost, SVR-RBF, MLP, LSTM, GRU.

Protocole :
  - cible strictement identique : F(t+1 h)
  - fenetre d'entree : t-23 h ... t
  - selection des hyperparametres sur validation uniquement
  - scalers ajustes sur train uniquement pendant la selection
  - re-entrainement final sur train + validation avec les hyperparametres retenus
  - test utilise une seule fois pour l'evaluation finale
  - scenarios A et B apparies sur les memes horodatages dans chaque partition

Le script n'utilise pas TensorFlow. Les reseaux MLP/LSTM/GRU sont implementes avec PyTorch.
"""



import os
import sys
import json
import time
import copy
import random
import warnings
import traceback
from pathlib import Path
from datetime import datetime

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import joblib

from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge
from sklearn.ensemble import RandomForestRegressor
from sklearn.svm import SVR
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

try:
    from xgboost import XGBRegressor
except Exception:
    XGBRegressor = None

try:
    import torch
    from torch import nn
    from torch.utils.data import DataLoader, TensorDataset
except Exception:
    torch = None
    nn = None
    DataLoader = None
    TensorDataset = None


# =============================================================================
# 1. CONFIGURATION UTILISATEUR
# =============================================================================

# Répertoire racine du projet
PROJECT_DIR = Path(__file__).resolve().parent.parent

# Dossiers des jeux de données A et B
SCENARIO_A_DIR = PROJECT_DIR / "resultats_prediction_t_plus_1h_modele_B"
SCENARIO_B_DIR = PROJECT_DIR / "resultats_scenario_B_electrothermique_t_plus_1h"

# Fichiers d'entrée
SCENARIO_A_FILE = "jeu_donnees_dynamique_complet_t_plus_1h.csv"
SCENARIO_B_FILE = "jeu_donnees_scenario_B_complet_t_plus_1h.csv"

# Dossier de sortie des expériences A/B
OUTPUT_DIR = PROJECT_DIR / "resultats_comparaison_architectures_t_plus_1h"

WINDOW_HOURS = 24
TARGET_COLUMN = "F_target_t_plus_1h_kN"
TARGET_TIME_COLUMN = "target_time_t_plus_1h"
INPUT_END_COLUMN = "input_end_time_t"
PARTITION_COLUMN = "partition"
BASELINE_A_COLUMN = "F_t_kN_baseline"

THERMAL_ELECTRICAL_FEATURES = [
    "Voltage [kV]",
    "Current [A]",
    "Ambient [degC]",
    "Top oil [degC]",
    "Bottom oil [degC]",
    "Mid-spot HV [degC]",
    "Mid-spot LV [degC]",
    "Hot-spot HV [degC]",
    "Hot-spot LV [degC]",
]
MECHANICAL_HISTORY_FEATURE = "F_clamp_kN_history"

RANDOM_SEED = 42
N_JOBS = -1
RF_N_ESTIMATORS = 350
XGB_MAX_ESTIMATORS = 700
XGB_EARLY_STOPPING_ROUNDS = 35
SVR_MAX_ITER = -1  # -1 = convergence LibSVM sans coupure arbitraire

# Parametres des reseaux de neurones (CPU compatible)
TORCH_MAX_EPOCHS = 100
TORCH_PATIENCE = 12
TORCH_BATCH_SIZE = 128
TORCH_LEARNING_RATE = 1e-3
TORCH_WEIGHT_DECAY = 1e-4
TORCH_NUM_WORKERS = 0

# Pour accelerer un essai initial, mettre True. Ne pas utiliser les resultats
# de ce mode dans l'article : il reduit les recherches d'hyperparametres.
SMOKE_TEST = False

# Les scenarios sont apparies sur l'intersection des horodatages de cible.
# Cela garantit que A et B sont evalues et entraines sur les memes observations.
PAIR_SCENARIOS_ON_COMMON_TIMESTAMPS = True


# =============================================================================
# 2. OUTILS GENERAUX
# =============================================================================

def set_global_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    if torch is not None:
        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)
        try:
            torch.use_deterministic_algorithms(False)
        except Exception:
            pass


def ensure_dependencies() -> None:
    missing = []
    if XGBRegressor is None:
        missing.append("xgboost")
    if torch is None:
        missing.append("torch")
    if missing:
        raise ImportError(
            "Dependances manquantes : " + ", ".join(missing) + "\n"
            "Dans Anaconda Prompt, execute :\n"
            "pip install xgboost torch\n"
            "Les autres dependances sont : numpy pandas scikit-learn matplotlib joblib."
        )


def safe_mkdir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def parse_dt(series: pd.Series, label: str) -> pd.Series:
    out = pd.to_datetime(series, errors="coerce", yearfirst=True)
    if out.isna().any():
        bad = series[out.isna()].head(5).tolist()
        raise ValueError(f"Dates non interpretables dans {label}. Exemples : {bad}")
    return out


def metrics_regression(y_true: np.ndarray, y_pred: np.ndarray) -> dict:
    y_true = np.asarray(y_true, dtype=float).reshape(-1)
    y_pred = np.asarray(y_pred, dtype=float).reshape(-1)
    err = y_pred - y_true
    return {
        "n": int(len(y_true)),
        "MAE_kN": float(mean_absolute_error(y_true, y_pred)),
        "RMSE_kN": float(np.sqrt(mean_squared_error(y_true, y_pred))),
        "R2": float(r2_score(y_true, y_pred)) if len(y_true) > 1 else np.nan,
        "Biais_moyen_kN": float(np.mean(err)),
        "Erreur_absolue_P95_kN": float(np.quantile(np.abs(err), 0.95)),
        "Erreur_absolue_max_kN": float(np.max(np.abs(err))),
    }


def flatten_config(config: dict) -> str:
    return json.dumps(config, ensure_ascii=False, sort_keys=True, default=str)


# =============================================================================
# 3. LECTURE ET CONTROLE DES SCENARIOS
# =============================================================================

def load_scenario(directory: Path, filename: str, scenario_name: str) -> tuple[pd.DataFrame, np.ndarray, list[str]]:
    csv_path = directory / filename
    if not csv_path.exists():
        raise FileNotFoundError(
            f"Fichier introuvable pour {scenario_name} : {csv_path}\n"
            "Verifie les chemins SCENARIO_A_DIR et SCENARIO_B_DIR au debut du script."
        )

    df = pd.read_csv(csv_path, low_memory=False)
    required = [TARGET_TIME_COLUMN, INPUT_END_COLUMN, TARGET_COLUMN, PARTITION_COLUMN]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(f"Colonnes obligatoires absentes dans {csv_path.name} : {missing}")

    df[TARGET_TIME_COLUMN] = parse_dt(df[TARGET_TIME_COLUMN], TARGET_TIME_COLUMN)
    df[INPUT_END_COLUMN] = parse_dt(df[INPUT_END_COLUMN], INPUT_END_COLUMN)
    df[TARGET_COLUMN] = pd.to_numeric(df[TARGET_COLUMN], errors="coerce")
    df[PARTITION_COLUMN] = df[PARTITION_COLUMN].astype(str).str.strip().str.lower()

    if df[TARGET_TIME_COLUMN].duplicated().any():
        dup = df.loc[df[TARGET_TIME_COLUMN].duplicated(), TARGET_TIME_COLUMN].head().tolist()
        raise ValueError(f"Horodatages cibles dupliques dans {scenario_name} : {dup}")

    delta = df[TARGET_TIME_COLUMN] - df[INPUT_END_COLUMN]
    bad_delta = delta != pd.Timedelta(hours=1)
    if bad_delta.any():
        examples = df.loc[bad_delta, [INPUT_END_COLUMN, TARGET_TIME_COLUMN]].head(5)
        raise ValueError(
            f"La relation t -> t+1h est incorrecte dans {scenario_name}.\n{examples}"
        )

    # Les colonnes des 24 heures sont ordonnees de la plus ancienne a la plus recente.
    bases = list(THERMAL_ELECTRICAL_FEATURES)
    if scenario_name == "A":
        if all(f"{MECHANICAL_HISTORY_FEATURE}__lag_{lag}h" in df.columns
               for lag in range(WINDOW_HOURS)):
            bases.append(MECHANICAL_HISTORY_FEATURE)
        else:
            raise ValueError("Scenario A : historique mecanique incomplet ou absent.")
    elif scenario_name == "B":
        # Le Scenario B ne doit contenir aucune variable d'historique de force.
        forbidden = [c for c in df.columns if MECHANICAL_HISTORY_FEATURE in c]
        if forbidden:
            raise ValueError(f"Fuite mecanique dans le Scenario B : {forbidden[:5]}")

    feature_columns = []
    for lag in range(WINDOW_HOURS - 1, -1, -1):
        for base in bases:
            col = f"{base}__lag_{lag}h"
            if col not in df.columns:
                raise ValueError(f"Variable d'entree absente dans {scenario_name} : {col}")
            feature_columns.append(col)

    x_flat = df[feature_columns].apply(pd.to_numeric, errors="coerce").to_numpy(dtype=np.float32)
    if not np.isfinite(x_flat).all():
        bad_count = int((~np.isfinite(x_flat)).sum())
        raise ValueError(
            f"{scenario_name} contient {bad_count} valeurs non finies dans les entrees. "
            "La preparation doit etre corrigee avant l'entrainement."
        )

    y = df[TARGET_COLUMN].to_numpy(dtype=np.float32)
    if not np.isfinite(y).all():
        raise ValueError(f"La cible contient des valeurs non finies dans {scenario_name}.")

    X = x_flat.reshape(len(df), WINDOW_HOURS, len(bases))
    df = df.sort_values(TARGET_TIME_COLUMN).reset_index(drop=True)
    order = np.argsort(pd.to_datetime(df[TARGET_TIME_COLUMN]).to_numpy())
    # Recalculer X/y selon l'ordre du DataFrame trie.
    x_flat = df[feature_columns].apply(pd.to_numeric, errors="coerce").to_numpy(dtype=np.float32)
    X = x_flat.reshape(len(df), WINDOW_HOURS, len(bases))
    y = pd.to_numeric(df[TARGET_COLUMN]).to_numpy(dtype=np.float32)

    print(f"{scenario_name}: {len(df)} sequences, X={X.shape}, colonnes={len(bases)} variables/heure")
    return df, X, bases


def align_scenarios(df_a: pd.DataFrame, Xa: np.ndarray,
                    df_b: pd.DataFrame, Xb: np.ndarray) -> dict:
    """Apparie A et B sur les memes dates cibles, dans chaque partition."""
    da = df_a.set_index(TARGET_TIME_COLUMN, drop=False)
    db = df_b.set_index(TARGET_TIME_COLUMN, drop=False)
    common_times = sorted(set(da.index).intersection(set(db.index)))
    if not common_times:
        raise ValueError("Aucun horodatage cible commun entre les scenarios A et B.")

    da = da.loc[common_times].copy()
    db = db.loc[common_times].copy()
    pos_a = {t: i for i, t in enumerate(df_a[TARGET_TIME_COLUMN])}
    pos_b = {t: i for i, t in enumerate(df_b[TARGET_TIME_COLUMN])}
    idx_a = np.array([pos_a[t] for t in common_times], dtype=int)
    idx_b = np.array([pos_b[t] for t in common_times], dtype=int)
    Xa_common = Xa[idx_a]
    Xb_common = Xb[idx_b]

    if not np.allclose(da[TARGET_COLUMN].to_numpy(), db[TARGET_COLUMN].to_numpy(), atol=1e-6, rtol=0):
        raise ValueError("Les cibles F(t+1) de A et B ne sont pas identiques aux dates communes.")
    if not (da[PARTITION_COLUMN].to_numpy() == db[PARTITION_COLUMN].to_numpy()).all():
        raise ValueError("Les partitions chronologiques A et B divergent sur les dates communes.")

    common = da.reset_index(drop=True)
    common["baseline_persistence_F_t_kN"] = pd.to_numeric(
        common[BASELINE_A_COLUMN], errors="coerce"
    ) if BASELINE_A_COLUMN in common.columns else np.nan

    # Les donnees sont ensuite coupees sur les memes horodatages et partitions.
    partitions = {}
    for part in ["train", "validation", "test"]:
        mask = common[PARTITION_COLUMN].to_numpy() == part
        idx = np.where(mask)[0]
        if len(idx) == 0:
            raise ValueError(f"Partition {part} vide apres appariement.")
        partitions[part] = {
            "meta": common.iloc[idx].reset_index(drop=True),
            "XA": Xa_common[idx],
            "XB": Xb_common[idx],
            "y": common.iloc[idx][TARGET_COLUMN].to_numpy(dtype=np.float32),
        }

    audit_rows = []
    for part in ["train", "validation", "test"]:
        na = int((df_a[PARTITION_COLUMN] == part).sum())
        nb = int((df_b[PARTITION_COLUMN] == part).sum())
        nc = len(partitions[part]["y"])
        audit_rows.append({
            "partition": part,
            "n_scenario_A_initial": na,
            "n_scenario_B_initial": nb,
            "n_horodatages_communs_utilises": nc,
            "A_exclus": na - nc,
            "B_exclus": nb - nc,
            "date_cible_debut_commune": partitions[part]["meta"][TARGET_TIME_COLUMN].min(),
            "date_cible_fin_commune": partitions[part]["meta"][TARGET_TIME_COLUMN].max(),
        })
    return partitions, pd.DataFrame(audit_rows)


# =============================================================================
# 4. NORMALISATION SANS FUITE
# =============================================================================

def fit_transform_x(X_train: np.ndarray, X_other: np.ndarray) -> tuple[np.ndarray, np.ndarray, StandardScaler]:
    n_features = X_train.shape[2]
    scaler = StandardScaler()
    scaler.fit(X_train.reshape(-1, n_features))
    Xtr = scaler.transform(X_train.reshape(-1, n_features)).reshape(X_train.shape).astype(np.float32)
    Xot = scaler.transform(X_other.reshape(-1, n_features)).reshape(X_other.shape).astype(np.float32)
    return Xtr, Xot, scaler


def transform_x_with_scaler(X: np.ndarray, scaler: StandardScaler) -> np.ndarray:
    shape = X.shape
    return scaler.transform(X.reshape(-1, shape[2])).reshape(shape).astype(np.float32)


def fit_y_scaler(y_train: np.ndarray) -> tuple[np.ndarray, StandardScaler]:
    scaler = StandardScaler()
    ys = scaler.fit_transform(y_train.reshape(-1, 1)).reshape(-1).astype(np.float32)
    return ys, scaler


def inverse_y(y_scaled: np.ndarray, scaler: StandardScaler) -> np.ndarray:
    return scaler.inverse_transform(np.asarray(y_scaled).reshape(-1, 1)).reshape(-1)


# =============================================================================
# 5. MODELES CLASSIQUES : RIDGE, RANDOM FOREST, XGBOOST, SVR
# =============================================================================

def candidate_grids(smoke: bool = False) -> dict:
    if smoke:
        return {
            "Ridge": [{"alpha": 10.0}],
            "RandomForest": [{"max_depth": 14, "min_samples_leaf": 2, "max_features": 1.0}],
            "XGBoost": [{"max_depth": 3, "learning_rate": 0.04, "subsample": 0.9, "colsample_bytree": 0.9, "reg_lambda": 5.0}],
            "SVR": [{"C": 10.0, "epsilon": 0.1, "gamma": "scale"}],
        }
    return {
        "Ridge": [
            {"alpha": 0.1}, {"alpha": 1.0}, {"alpha": 10.0}, {"alpha": 100.0}
        ],
        "RandomForest": [
            {"max_depth": None, "min_samples_leaf": 1, "max_features": 1.0},
            {"max_depth": 16, "min_samples_leaf": 2, "max_features": 1.0},
        ],
        "XGBoost": [
            {"max_depth": 2, "learning_rate": 0.03, "subsample": 0.9, "colsample_bytree": 0.9, "reg_lambda": 5.0},
            {"max_depth": 3, "learning_rate": 0.04, "subsample": 0.9, "colsample_bytree": 0.9, "reg_lambda": 5.0},
        ],
        "SVR": [
            {"C": 10.0, "epsilon": 0.05, "gamma": "scale"},
            {"C": 50.0, "epsilon": 0.05, "gamma": "scale"},
        ],
    }


def make_xgb(params: dict, n_estimators: int, early_stopping: bool):
    kwargs = dict(
        objective="reg:squarederror",
        n_estimators=int(n_estimators),
        max_depth=int(params["max_depth"]),
        learning_rate=float(params["learning_rate"]),
        subsample=float(params["subsample"]),
        colsample_bytree=float(params["colsample_bytree"]),
        reg_lambda=float(params["reg_lambda"]),
        random_state=RANDOM_SEED,
        n_jobs=N_JOBS,
        tree_method="hist",
        eval_metric="rmse",
        verbosity=0,
    )
    if early_stopping:
        kwargs["early_stopping_rounds"] = XGB_EARLY_STOPPING_ROUNDS
    return XGBRegressor(**kwargs)


def train_classical_model(model_name: str, Xtr3: np.ndarray, ytr_s: np.ndarray,
                          Xval3: np.ndarray, yval_s: np.ndarray,
                          y_scaler: StandardScaler, params: dict,
                          scenario: str, candidate_index: int):
    Xtr = Xtr3.reshape(len(Xtr3), -1)
    Xval = Xval3.reshape(len(Xval3), -1)
    fitted_rounds = None

    if model_name == "Ridge":
        model = Ridge(alpha=float(params["alpha"]))
        model.fit(Xtr, ytr_s)
    elif model_name == "RandomForest":
        model = RandomForestRegressor(
            n_estimators=RF_N_ESTIMATORS,
            max_depth=params["max_depth"],
            min_samples_leaf=int(params["min_samples_leaf"]),
            max_features=params["max_features"],
            random_state=RANDOM_SEED,
            n_jobs=N_JOBS,
        )
        model.fit(Xtr, ytr_s)
    elif model_name == "XGBoost":
        model = make_xgb(params, XGB_MAX_ESTIMATORS, early_stopping=True)
        model.fit(Xtr, ytr_s, eval_set=[(Xval, yval_s)], verbose=False)
        fitted_rounds = int(getattr(model, "best_iteration", XGB_MAX_ESTIMATORS - 1)) + 1
    elif model_name == "SVR":
        model = SVR(
            kernel="rbf",
            C=float(params["C"]),
            epsilon=float(params["epsilon"]),
            gamma=params["gamma"],
            cache_size=1000,
            max_iter=SVR_MAX_ITER,
            tol=1e-3,
        )
        model.fit(Xtr, ytr_s)
    else:
        raise ValueError(f"Modele classique inconnu : {model_name}")

    val_pred_s = model.predict(Xval)
    val_pred = inverse_y(val_pred_s, y_scaler)
    return model, val_pred, fitted_rounds


def refit_classical_model(model_name: str, Xtrainval3: np.ndarray, ytrainval: np.ndarray,
                          params: dict, scenario: str, best_rounds: int | None = None):
    x_scaler = StandardScaler()
    n_features = Xtrainval3.shape[2]
    x_scaler.fit(Xtrainval3.reshape(-1, n_features))
    Xs = x_scaler.transform(Xtrainval3.reshape(-1, n_features)).reshape(Xtrainval3.shape).astype(np.float32)
    Xflat = Xs.reshape(len(Xs), -1)
    y_scaler = StandardScaler()
    ys = y_scaler.fit_transform(ytrainval.reshape(-1, 1)).reshape(-1)

    if model_name == "Ridge":
        model = Ridge(alpha=float(params["alpha"]))
    elif model_name == "RandomForest":
        model = RandomForestRegressor(
            n_estimators=RF_N_ESTIMATORS,
            max_depth=params["max_depth"],
            min_samples_leaf=int(params["min_samples_leaf"]),
            max_features=params["max_features"],
            random_state=RANDOM_SEED,
            n_jobs=N_JOBS,
        )
    elif model_name == "XGBoost":
        model = make_xgb(params, best_rounds or XGB_MAX_ESTIMATORS, early_stopping=False)
    elif model_name == "SVR":
        model = SVR(
            kernel="rbf", C=float(params["C"]), epsilon=float(params["epsilon"]),
            gamma=params["gamma"], cache_size=1000, max_iter=SVR_MAX_ITER, tol=1e-3
        )
    else:
        raise ValueError(model_name)
    model.fit(Xflat, ys)
    return model, x_scaler, y_scaler


# =============================================================================
# 6. RESEAUX DE NEURONES : MLP, LSTM, GRU
# =============================================================================

class MLPNetwork(nn.Module):
    def __init__(self, input_size: int, hidden: tuple[int, ...], dropout: float = 0.15):
        super().__init__()
        layers = []
        prev = input_size
        for width in hidden:
            layers.extend([nn.Linear(prev, width), nn.ReLU(), nn.Dropout(dropout)])
            prev = width
        layers.append(nn.Linear(prev, 1))
        self.net = nn.Sequential(*layers)

    def forward(self, x):
        return self.net(x.reshape(x.shape[0], -1)).squeeze(-1)


class RecurrentNetwork(nn.Module):
    def __init__(self, input_size: int, hidden_size: int, kind: str, dropout: float = 0.15):
        super().__init__()
        recurrent_class = nn.LSTM if kind == "LSTM" else nn.GRU
        self.input_dropout = nn.Dropout(dropout)
        self.rnn = recurrent_class(
            input_size=input_size,
            hidden_size=hidden_size,
            num_layers=1,
            batch_first=True,
        )
        self.head = nn.Sequential(
            nn.Dropout(dropout),
            nn.Linear(hidden_size, max(16, hidden_size // 2)),
            nn.ReLU(),
            nn.Linear(max(16, hidden_size // 2), 1),
        )

    def forward(self, x):
        x = self.input_dropout(x)
        seq, _ = self.rnn(x)
        return self.head(seq[:, -1, :]).squeeze(-1)


def make_torch_model(kind: str, n_features: int, config: dict):
    if kind == "MLP":
        return MLPNetwork(n_features * WINDOW_HOURS, tuple(config["hidden"]), config.get("dropout", 0.15))
    if kind in ("LSTM", "GRU"):
        return RecurrentNetwork(n_features, int(config["hidden_size"]), kind, config.get("dropout", 0.15))
    raise ValueError(kind)


def torch_predict(model, X: np.ndarray, device: str) -> np.ndarray:
    model.eval()
    outputs = []
    with torch.no_grad():
        for start in range(0, len(X), 512):
            xb = torch.as_tensor(X[start:start + 512], dtype=torch.float32, device=device)
            pred = model(xb).detach().cpu().numpy().reshape(-1)
            outputs.append(pred)
    return np.concatenate(outputs) if outputs else np.array([], dtype=float)


def train_torch_candidate(kind: str, config: dict,
                          Xtr: np.ndarray, ytr: np.ndarray,
                          Xval: np.ndarray, yval: np.ndarray,
                          n_features: int, seed: int) -> tuple[float, int, np.ndarray]:
    """Entrainement avec arret anticipe; renvoie RMSE val, epoch et predictions val standardisees."""
    set_global_seed(seed)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    model = make_torch_model(kind, n_features, config).to(device)
    optimizer = torch.optim.AdamW(
        model.parameters(), lr=TORCH_LEARNING_RATE, weight_decay=TORCH_WEIGHT_DECAY
    )
    loss_fn = nn.MSELoss()

    ds = TensorDataset(
        torch.as_tensor(Xtr, dtype=torch.float32),
        torch.as_tensor(ytr, dtype=torch.float32),
    )
    loader = DataLoader(
        ds, batch_size=TORCH_BATCH_SIZE, shuffle=True,
        num_workers=TORCH_NUM_WORKERS, drop_last=False
    )
    xv = torch.as_tensor(Xval, dtype=torch.float32, device=device)
    yv = np.asarray(yval, dtype=float)

    best_loss = np.inf
    best_epoch = 1
    best_state = None
    patience_count = 0
    for epoch in range(1, TORCH_MAX_EPOCHS + 1):
        model.train()
        for xb_cpu, yb_cpu in loader:
            xb = xb_cpu.to(device)
            yb = yb_cpu.to(device)
            optimizer.zero_grad(set_to_none=True)
            pred = model(xb)
            loss = loss_fn(pred, yb)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=2.0)
            optimizer.step()

        model.eval()
        with torch.no_grad():
            val_pred = model(xv).detach().cpu().numpy().reshape(-1)
        val_rmse = float(np.sqrt(mean_squared_error(yv, val_pred)))
        if val_rmse < best_loss - 1e-6:
            best_loss = val_rmse
            best_epoch = epoch
            best_state = copy.deepcopy(model.state_dict())
            patience_count = 0
        else:
            patience_count += 1
        if patience_count >= TORCH_PATIENCE:
            break

    if best_state is not None:
        model.load_state_dict(best_state)
    model.eval()
    with torch.no_grad():
        best_val_predictions = model(xv).detach().cpu().numpy().reshape(-1)
    return best_loss, best_epoch, best_val_predictions


def train_torch_fixed_epochs(kind: str, config: dict,
                             Xtrainval: np.ndarray, ytrainval: np.ndarray,
                             n_features: int, epochs: int, seed: int):
    """Re-entraine le reseau retenu sur train+validation pendant le nombre d'epochs choisi."""
    set_global_seed(seed)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    model = make_torch_model(kind, n_features, config).to(device)
    optimizer = torch.optim.AdamW(
        model.parameters(), lr=TORCH_LEARNING_RATE, weight_decay=TORCH_WEIGHT_DECAY
    )
    loss_fn = nn.MSELoss()
    ds = TensorDataset(
        torch.as_tensor(Xtrainval, dtype=torch.float32),
        torch.as_tensor(ytrainval, dtype=torch.float32),
    )
    loader = DataLoader(ds, batch_size=TORCH_BATCH_SIZE, shuffle=True,
                        num_workers=TORCH_NUM_WORKERS, drop_last=False)
    for _ in range(max(1, int(epochs))):
        model.train()
        for xb_cpu, yb_cpu in loader:
            xb = xb_cpu.to(device)
            yb = yb_cpu.to(device)
            optimizer.zero_grad(set_to_none=True)
            pred = model(xb)
            loss = loss_fn(pred, yb)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=2.0)
            optimizer.step()
    return model


def neural_grids(smoke: bool = False) -> dict:
    if smoke:
        return {
            "MLP": [{"hidden": [64, 32], "dropout": 0.1}],
            "LSTM": [{"hidden_size": 32, "dropout": 0.1}],
            "GRU": [{"hidden_size": 32, "dropout": 0.1}],
        }
    return {
        "MLP": [
            {"hidden": [128, 64], "dropout": 0.15},
            {"hidden": [256, 128], "dropout": 0.15},
        ],
        "LSTM": [
            {"hidden_size": 32, "dropout": 0.15},
            {"hidden_size": 64, "dropout": 0.15},
        ],
        "GRU": [
            {"hidden_size": 32, "dropout": 0.15},
            {"hidden_size": 64, "dropout": 0.15},
        ],
    }


# =============================================================================
# 7. ENTRAINEMENT D'UN SCENARIO
# =============================================================================

def run_one_scenario(scenario_name: str, X_train: np.ndarray, y_train: np.ndarray,
                     X_val: np.ndarray, y_val: np.ndarray,
                     X_test: np.ndarray, y_test: np.ndarray,
                     output_dir: Path, smoke: bool = False) -> tuple[list[dict], pd.DataFrame, dict]:
    print("\n" + "=" * 78)
    print(f"ENTRAINEMENT DU SCENARIO {scenario_name}")
    print("=" * 78)

    scenario_dir = output_dir / f"Scenario_{scenario_name}"
    model_dir = scenario_dir / "modeles"
    safe_mkdir(model_dir)

    # 1. Scalers de selection : ajustes exclusivement sur train.
    Xtr_s, Xval_s, x_scaler_sel = fit_transform_x(X_train, X_val)
    ytr_s, y_scaler_sel = fit_y_scaler(y_train)
    yval_s = y_scaler_sel.transform(y_val.reshape(-1, 1)).reshape(-1).astype(np.float32)

    classic_grids = candidate_grids(smoke)
    neural_search = neural_grids(smoke)
    search_rows = []
    selected = {}

    # Modeles classiques
    for model_name in ["Ridge", "RandomForest", "XGBoost", "SVR"]:
        best = None
        for ci, params in enumerate(classic_grids[model_name], start=1):
            start = time.time()
            print(f"[{scenario_name}] {model_name} candidat {ci}/{len(classic_grids[model_name])} : {params}")
            model, pred_val, rounds = train_classical_model(
                model_name, Xtr_s, ytr_s, Xval_s, yval_s, y_scaler_sel,
                params, scenario_name, ci
            )
            met = metrics_regression(y_val, pred_val)
            row = {
                "scenario": scenario_name,
                "architecture": model_name,
                "candidat": ci,
                "parametres": flatten_config(params),
                "best_rounds_XGBoost": rounds,
                "temps_selection_s": time.time() - start,
                **met,
            }
            search_rows.append(row)
            if best is None or met["RMSE_kN"] < best["val_rmse"]:
                best = {
                    "params": params,
                    "val_rmse": met["RMSE_kN"],
                    "val_metrics": met,
                    "best_rounds": rounds,
                }
        selected[model_name] = best
        print(f"  -> retenu validation RMSE={best['val_rmse']:.5f} kN | {best['params']}")

    # Reseaux neuronaux
    for model_name in ["MLP", "LSTM", "GRU"]:
        best = None
        for ci, params in enumerate(neural_search[model_name], start=1):
            start = time.time()
            print(f"[{scenario_name}] {model_name} candidat {ci}/{len(neural_search[model_name])} : {params}")
            val_rmse_scaled, best_epoch, val_pred_scaled = train_torch_candidate(
                model_name, params, Xtr_s, ytr_s, Xval_s, yval_s,
                X_train.shape[2], RANDOM_SEED + ci
            )
            val_pred_kn = inverse_y(val_pred_scaled, y_scaler_sel)
            val_metrics = metrics_regression(y_val, val_pred_kn)
            val_rmse_kn = val_metrics["RMSE_kN"]
            row = {
                "scenario": scenario_name,
                "architecture": model_name,
                "candidat": ci,
                "parametres": flatten_config(params),
                "best_epoch": int(best_epoch),
                "temps_selection_s": time.time() - start,
                **val_metrics,
            }
            # On garde une seule mesure de selection RMSE ; les predictions val completes
            # ne sont pas sauvegardees pour eviter de charger inutilement la memoire.
            search_rows.append(row)
            if best is None or val_rmse_kn < best["val_rmse"]:
                best = {
                    "params": params,
                    "val_rmse": val_rmse_kn,
                    "best_epoch": best_epoch,
                }
        selected[model_name] = best
        print(f"  -> retenu validation RMSE={best['val_rmse']:.5f} kN | {best['params']} | epochs={best.get('best_epoch')}")

    # 2. Refit final sur train+validation, sans toucher au test.
    X_trainval = np.concatenate([X_train, X_val], axis=0)
    y_trainval = np.concatenate([y_train, y_val], axis=0)
    Xtrainval_s, Xtest_s, x_scaler_final = fit_transform_x(X_trainval, X_test)
    ytrainval_s, y_scaler_final = fit_y_scaler(y_trainval)
    test_predictions = {}
    final_model_info = {}

    for model_name in ["Ridge", "RandomForest", "XGBoost", "SVR"]:
        best = selected[model_name]
        start = time.time()
        model, xs, ys = refit_classical_model(
            model_name, X_trainval, y_trainval, best["params"], scenario_name,
            best_rounds=best.get("best_rounds")
        )
        Xtest_flat = Xtest_s.reshape(len(Xtest_s), -1)
        pred_s = model.predict(Xtest_flat)
        pred = inverse_y(pred_s, ys)
        test_predictions[model_name] = pred
        feature_bases = THERMAL_ELECTRICAL_FEATURES + ([MECHANICAL_HISTORY_FEATURE] if scenario_name == "A" else [])
        joblib.dump({"model": model, "x_scaler": xs, "y_scaler": ys,
                     "feature_bases": feature_bases, "window_hours": WINDOW_HOURS,
                     "scenario": scenario_name, "architecture": model_name,
                     "params": best["params"]}, model_dir / f"{model_name}.joblib")
        final_model_info[model_name] = {
            "params": best["params"],
            "validation_RMSE_kN": best["val_rmse"],
            "temps_refit_s": time.time() - start,
        }
        print(f"[{scenario_name}] {model_name} finalise.")

    for model_name in ["MLP", "LSTM", "GRU"]:
        best = selected[model_name]
        start = time.time()
        model = train_torch_fixed_epochs(
            model_name, best["params"], Xtrainval_s, ytrainval_s,
            X_train.shape[2], best["best_epoch"], RANDOM_SEED + 100
        )
        device = "cuda" if torch.cuda.is_available() else "cpu"
        pred_s = torch_predict(model, Xtest_s, device)
        pred = inverse_y(pred_s, y_scaler_final)
        test_predictions[model_name] = pred
        torch.save({
            "state_dict": model.state_dict(),
            "scenario": scenario_name,
            "architecture": model_name,
            "params": best["params"],
            "feature_bases": THERMAL_ELECTRICAL_FEATURES + ([MECHANICAL_HISTORY_FEATURE] if scenario_name == "A" else []),
            "window_hours": WINDOW_HOURS,
            "n_features": int(X_train.shape[2]),
            "feature_scaler_mean": x_scaler_final.mean_.tolist(),
            "feature_scaler_scale": x_scaler_final.scale_.tolist(),
            "target_scaler_mean": y_scaler_final.mean_.tolist(),
            "target_scaler_scale": y_scaler_final.scale_.tolist(),
            "epochs": int(best["best_epoch"]),
        }, model_dir / f"{model_name}.pt")
        final_model_info[model_name] = {
            "params": best["params"],
            "best_epoch": int(best["best_epoch"]),
            "validation_RMSE_kN": best["val_rmse"],
            "temps_refit_s": time.time() - start,
        }
        print(f"[{scenario_name}] {model_name} finalise.")

    # Scalers finaux en fichier autonome pour faciliter la reutilisation.
    joblib.dump({"x_scaler": x_scaler_final, "y_scaler": y_scaler_final,
                 "window_hours": WINDOW_HOURS, "scenario": scenario_name},
                model_dir / "scalers_finaux.joblib")

    test_rows = []
    for model_name, pred in test_predictions.items():
        met = metrics_regression(y_test, pred)
        test_rows.append({"scenario": scenario_name, "architecture": model_name, **met})
    test_metrics = pd.DataFrame(test_rows).sort_values("RMSE_kN")

    search_df = pd.DataFrame(search_rows)
    search_df.to_csv(scenario_dir / "resultats_recherche_validation.csv", index=False, encoding="utf-8-sig")
    test_metrics.to_csv(scenario_dir / "metriques_test_finales.csv", index=False, encoding="utf-8-sig")
    with open(scenario_dir / "hyperparametres_retenus.json", "w", encoding="utf-8") as f:
        json.dump(final_model_info, f, ensure_ascii=False, indent=2, default=str)

    return test_rows, test_metrics, {"predictions": test_predictions, "selected": final_model_info, "search": search_df}


# =============================================================================
# 8. GRAPHIQUES, COMPARAISONS ET RAPPORT
# =============================================================================

def save_global_outputs(output_dir: Path, partitions: dict,
                        result_A: dict, result_B: dict,
                        test_rows_all: list[dict], alignment_audit: pd.DataFrame) -> None:
    safe_mkdir(output_dir / "graphiques")
    safe_mkdir(output_dir / "predictions")
    test_meta = partitions["test"]["meta"].copy()
    y_test = partitions["test"]["y"]

    pred_df = pd.DataFrame({
        "target_time_t_plus_1h": test_meta[TARGET_TIME_COLUMN].astype(str),
        "F_reelle_kN": y_test,
        "F_persistance_F_t_kN": test_meta["baseline_persistence_F_t_kN"],
    })
    for model, pred in result_A["predictions"].items():
        pred_df[f"A_{model}_kN"] = pred
    for model, pred in result_B["predictions"].items():
        pred_df[f"B_{model}_kN"] = pred
    pred_df.to_csv(output_dir / "predictions" / "predictions_test_pairees.csv", index=False, encoding="utf-8-sig")

    metrics_df = pd.DataFrame(test_rows_all)
    metrics_df.to_csv(output_dir / "metriques_test_tous_modeles.csv", index=False, encoding="utf-8-sig")

    # Tableau A/B : delta positif = scenario A a une erreur plus elevee que B.
    piv = metrics_df.pivot(index="architecture", columns="scenario", values="RMSE_kN").reset_index()
    if "A" in piv.columns and "B" in piv.columns:
        piv["Delta_RMSE_A_moins_B_kN"] = piv["A"] - piv["B"]
    piv.to_csv(output_dir / "comparaison_scenarios_A_vs_B_RMSE.csv", index=False, encoding="utf-8-sig")
    alignment_audit.to_csv(output_dir / "audit_appairage_scenarios.csv", index=False, encoding="utf-8-sig")

    # Performance mensuelle sur le test, utile pour examiner la derive temporelle.
    rows_month = []
    months = pd.to_datetime(test_meta[TARGET_TIME_COLUMN]).dt.to_period("M").astype(str).to_numpy()
    for scenario, result in [("A", result_A), ("B", result_B)]:
        for model, pred in result["predictions"].items():
            for month in sorted(np.unique(months)):
                mask = months == month
                if mask.sum() >= 2:
                    met = metrics_regression(y_test[mask], pred[mask])
                    rows_month.append({"scenario": scenario, "architecture": model,
                                       "mois": month, **met})
    pd.DataFrame(rows_month).to_csv(output_dir / "metriques_test_par_mois.csv", index=False, encoding="utf-8-sig")

    # RMSE groupe A/B
    archs = ["Ridge", "RandomForest", "XGBoost", "SVR", "MLP", "LSTM", "GRU"]
    fig, ax = plt.subplots(figsize=(12, 6))
    x = np.arange(len(archs))
    width = 0.36
    map_rmse = {(r["scenario"], r["architecture"]): r["RMSE_kN"] for r in test_rows_all}
    vals_a = [map_rmse.get(("A", a), np.nan) for a in archs]
    vals_b = [map_rmse.get(("B", a), np.nan) for a in archs]
    ax.bar(x - width / 2, vals_a, width, label="Scenario A : electrothermique + force passee")
    ax.bar(x + width / 2, vals_b, width, label="Scenario B : electrothermique seul")
    ax.set_xticks(x)
    ax.set_xticklabels(archs, rotation=20, ha="right")
    ax.set_ylabel("RMSE test (kN)")
    ax.set_title("Comparaison des architectures sur les memes dates de test")
    ax.grid(axis="y", alpha=0.25)
    ax.legend()
    fig.tight_layout()
    fig.savefig(output_dir / "graphiques" / "comparaison_RMSE_test_A_B.png", dpi=160)
    plt.close(fig)

    # Chronologie des predictions des meilleurs modeles A et B.
    best_A = min(result_A["predictions"], key=lambda m: metrics_regression(y_test, result_A["predictions"][m])["RMSE_kN"])
    best_B = min(result_B["predictions"], key=lambda m: metrics_regression(y_test, result_B["predictions"][m])["RMSE_kN"])
    dates = pd.to_datetime(test_meta[TARGET_TIME_COLUMN])
    fig, ax = plt.subplots(figsize=(15, 6))
    ax.plot(dates, y_test, label="Force reelle", linewidth=1.2)
    ax.plot(dates, result_A["predictions"][best_A], label=f"Scenario A - {best_A}", linewidth=1.0)
    ax.plot(dates, result_B["predictions"][best_B], label=f"Scenario B - {best_B}", linewidth=1.0)
    ax.set_title("Predictions finales sur la periode de test")
    ax.set_ylabel("Force de serrage (kN)")
    ax.set_xlabel("Date cible")
    ax.grid(alpha=0.25)
    ax.legend()
    fig.tight_layout()
    fig.savefig(output_dir / "graphiques" / "meilleures_predictions_test.png", dpi=160)
    plt.close(fig)

    # Rapport synthese.
    lines = []
    lines.append("RAPPORT - COMPARAISON D'ARCHITECTURES POUR LA PREDICTION A t+1 HEURE")
    lines.append("=" * 78)
    lines.append(f"Date execution : {datetime.now().isoformat(timespec='seconds')}")
    lines.append(f"Fenetre historique : {WINDOW_HOURS} heures")
    lines.append("Cible : F_clamp(t+1h), uniquement a partir des informations disponibles jusqu'a t.")
    lines.append("Selection hyperparametres : validation. Evaluation finale : test non utilise pour selection.")
    lines.append("A et B sont apparies sur les memes horodatages dans chaque partition.")
    lines.append("")
    lines.append("EFFECTIFS APPARIES")
    lines.append(alignment_audit.to_string(index=False))
    lines.append("")
    lines.append("METRIQUES FINALES SUR TEST COMMUN")
    lines.append(metrics_df.sort_values(["scenario", "RMSE_kN"]).to_string(index=False))
    lines.append("")
    lines.append("COMPARAISON A - B (Delta RMSE positif : A est moins performant)")
    lines.append(piv.to_string(index=False))
    lines.append("")
    lines.append("MEILLEURS MODELES OBSERVES SUR LE TEST (descriptif, pas une selection pour deploiement)")
    lines.append(f"Scenario A : {best_A}")
    lines.append(f"Scenario B : {best_B}")
    lines.append("")
    lines.append("PRECAUTIONS D'INTERPRETATION")
    lines.append("- Le test est une seule periode temporelle (fin 2024) : la generalisation a d'autres transformateurs n'est pas demontree.")
    lines.append("- Le scenario A utilise l'historique mesure de force ; le scenario B ne l'utilise pas.")
    lines.append("- Les performances ne prouvent pas une causalite physique.")
    lines.append("- Les architectures ont ete comparees sur les memes dates cibles pour isoler l'effet des variables d'entree.")
    lines.append("- Une validation externe sur un autre transformateur ou une autre periode reste necessaire.")
    with open(output_dir / "RAPPORT_COMPARAISON_ARCHITECTURES.txt", "w", encoding="utf-8") as f:
        f.write("\n".join(lines))


# =============================================================================
# 9. EXECUTION PRINCIPALE
# =============================================================================

def main() -> None:
    warnings.filterwarnings("ignore", category=FutureWarning)
    set_global_seed(RANDOM_SEED)
    ensure_dependencies()

    if torch is not None:
        try:
            torch.set_num_threads(max(1, min(4, os.cpu_count() or 1)))
        except Exception:
            pass

    safe_mkdir(OUTPUT_DIR)
    print("\n" + "=" * 78)
    print("COMPARAISON DES 7 ARCHITECTURES - PREDICTION A t+1 HEURE")
    print("=" * 78)
    print(f"Scenario A : {SCENARIO_A_DIR}")
    print(f"Scenario B : {SCENARIO_B_DIR}")
    print(f"Sortie     : {OUTPUT_DIR}")
    print(f"Mode test rapide : {SMOKE_TEST}")

    df_a, Xa, bases_a = load_scenario(SCENARIO_A_DIR, SCENARIO_A_FILE, "A")
    df_b, Xb, bases_b = load_scenario(SCENARIO_B_DIR, SCENARIO_B_FILE, "B")

    if bases_a != bases_b + [MECHANICAL_HISTORY_FEATURE]:
        raise ValueError(
            "Les variables A/B ne sont pas conformes a l'experience prevue.\n"
            f"A : {bases_a}\nB : {bases_b}"
        )

    if PAIR_SCENARIOS_ON_COMMON_TIMESTAMPS:
        partitions, alignment_audit = align_scenarios(df_a, Xa, df_b, Xb)
    else:
        raise NotImplementedError(
            "Ce script est volontairement configure pour une comparaison appairee A/B. "
            "Conserve PAIR_SCENARIOS_ON_COMMON_TIMESTAMPS=True."
        )

    print("\nEffectifs apparies :")
    print(alignment_audit.to_string(index=False))

    # Enregistrement de la configuration et de l'audit d'entree.
    config_dump = {
        "scenario_A_dir": str(SCENARIO_A_DIR),
        "scenario_B_dir": str(SCENARIO_B_DIR),
        "scenario_A_file": SCENARIO_A_FILE,
        "scenario_B_file": SCENARIO_B_FILE,
        "window_hours": WINDOW_HOURS,
        "target": TARGET_COLUMN,
        "target_time": TARGET_TIME_COLUMN,
        "features_A": bases_a,
        "features_B": bases_b,
        "seed": RANDOM_SEED,
        "smoke_test": SMOKE_TEST,
        "paired_timestamps": True,
        "models": ["Ridge", "RandomForest", "XGBoost", "SVR", "MLP", "LSTM", "GRU"],
    }
    with open(OUTPUT_DIR / "configuration_experimentale.json", "w", encoding="utf-8") as f:
        json.dump(config_dump, f, ensure_ascii=False, indent=2)

    # Affichage / controle de la reference de persistance (mesure F(t), hors X du B).
    baseline_rows = []
    for part in ["train", "validation", "test"]:
        meta = partitions[part]["meta"]
        mask = pd.to_numeric(meta["baseline_persistence_F_t_kN"], errors="coerce").notna().to_numpy()
        if mask.any():
            met = metrics_regression(
                partitions[part]["y"][mask],
                pd.to_numeric(meta.loc[mask, "baseline_persistence_F_t_kN"]).to_numpy(dtype=float)
            )
            baseline_rows.append({"partition": part, **met, "couverture_pct": 100 * mask.mean()})
    pd.DataFrame(baseline_rows).to_csv(OUTPUT_DIR / "baseline_persistance_sur_dates_communes.csv", index=False, encoding="utf-8-sig")

    # Les deux scenarios sont entraines sur les memes cibles temporelles.
    tr, va, te = partitions["train"], partitions["validation"], partitions["test"]

    test_rows_all = []
    # Reference commune : F(t) -> F(t+1h), calculee hors des entrees du Scenario B.
    test_meta_common = te["meta"]
    baseline_mask_test = pd.to_numeric(test_meta_common["baseline_persistence_F_t_kN"], errors="coerce").notna().to_numpy()
    if baseline_mask_test.any():
        baseline_metrics_test = metrics_regression(
            te["y"][baseline_mask_test],
            pd.to_numeric(test_meta_common.loc[baseline_mask_test, "baseline_persistence_F_t_kN"]).to_numpy(dtype=float)
        )
        test_rows_all.append({"scenario": "Reference", "architecture": "Persistence_F_t", **baseline_metrics_test})

    result_A_rows, metrics_A, result_A = run_one_scenario(
        "A", tr["XA"], tr["y"], va["XA"], va["y"], te["XA"], te["y"], OUTPUT_DIR, SMOKE_TEST
    )
    test_rows_all.extend(result_A_rows)

    result_B_rows, metrics_B, result_B = run_one_scenario(
        "B", tr["XB"], tr["y"], va["XB"], va["y"], te["XB"], te["y"], OUTPUT_DIR, SMOKE_TEST
    )
    test_rows_all.extend(result_B_rows)

    save_global_outputs(OUTPUT_DIR, partitions, result_A, result_B, test_rows_all, alignment_audit)

    print("\n" + "=" * 78)
    print("ENTRAINEMENT ET COMPARAISON TERMINES")
    print("=" * 78)
    print(f"Dossier : {OUTPUT_DIR}")
    print("\nMetriques test :")
    print(pd.DataFrame(test_rows_all).sort_values(["scenario", "RMSE_kN"]).to_string(index=False))
    print("\nFichier principal a transmettre : RAPPORT_COMPARAISON_ARCHITECTURES.txt")
    print("Compresse tout le dossier de resultats avant de me l'envoyer.")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print("\nERREUR DANS LE SCRIPT :")
        print(str(exc))
        traceback.print_exc()
        raise
