# -*- coding: utf-8 -*-
"""
Created on Sun Nov  1 20:26:37 2026

@author: Leni
"""

# -*- coding: utf-8 -*-
"""
SCENARIO B - PREDICTION DE LA FORCE DE SERRAGE A t+1h
====================================================

Objectif
--------
Construire le scenario electrothermique pur : les entrees contiennent uniquement
les 9 variables electriques et thermiques disponibles de t-23h a t.
La force de serrage passee est EXCLUE des tenseurs X.
La cible est F_clamp(t+1h).

Important
---------
- Utilise la serie_horaire_auditee.csv produite par le script de preparation.
- Reprend les memes limites chronologiques que le Scenario A.
- Ne comble aucune lacune temporelle et n'interpole aucune mesure.
- La force F(t) n'est conservee que dans le fichier de reference de persistance,
  jamais dans les variables X du Scenario B.

Dependances : pandas, numpy. Matplotlib est facultatif pour les graphiques.
"""

from pathlib import Path
import sys
import json
import numpy as np
import pandas as pd

# ============================================================================
# CONFIGURATION UTILISATEUR
# ============================================================================

# Répertoire racine du projet
PROJECT_DIR = Path(__file__).resolve().parent.parent

# Dossier des résultats du scénario A
SCENARIO_A_DIR = PROJECT_DIR / "resultats_prediction_t_plus_1h_modele_B"

# Fichiers produits par le scénario A
SERIES_FILE = SCENARIO_A_DIR / "serie_horaire_auditee.csv"

SCENARIO_A_DATASET = (
    SCENARIO_A_DIR / "jeu_donnees_dynamique_complet_t_plus_1h.csv"
)

# Dossier de sortie du scénario B
OUTPUT_DIR = (
    PROJECT_DIR / "resultats_scenario_B_electrothermique_t_plus_1h"
)

TIMESTAMP_COLUMN = "timestamp"
TARGET_COLUMN = "F_clamp_kN"
WINDOW_HOURS = 24

FEATURE_COLUMNS = [
    "Voltage [kV]",
    "Current [A]",
    "Ambient [degC]",
    "Top oil [degC]",
    "Bottom oil [degC]",
    "Mid-spot HV [degC]",
    "Mid-spot LV [degC]",
    "Hot-spot HV [degC]",
    "Hot-spot LV [degC]",
]

TIMESTAMP_COLUMN = "timestamp"
TARGET_COLUMN = "F_clamp_kN"
WINDOW_HOURS = 24

# Les neuf variables retenues dans le fichier audite.
FEATURE_COLUMNS = [
    "Voltage [kV]",
    "Current [A]",
    "Ambient [degC]",
    "Top oil [degC]",
    "Bottom oil [degC]",
    "Mid-spot HV [degC]",
    "Mid-spot LV [degC]",
    "Hot-spot HV [degC]",
    "Hot-spot LV [degC]",
]

# ============================================================================
# FONCTIONS
# ============================================================================

def stop(message):
    raise RuntimeError(message)


def metricas(y_true, y_pred):
    y_true = np.asarray(y_true, dtype=float)
    y_pred = np.asarray(y_pred, dtype=float)
    mask = np.isfinite(y_true) & np.isfinite(y_pred)
    y_true, y_pred = y_true[mask], y_pred[mask]
    if len(y_true) == 0:
        return {"n": 0, "MAE_kN": np.nan, "RMSE_kN": np.nan, "R2": np.nan}
    err = y_true - y_pred
    mae = float(np.mean(np.abs(err)))
    rmse = float(np.sqrt(np.mean(err ** 2)))
    den = float(np.sum((y_true - np.mean(y_true)) ** 2))
    r2 = float(1 - np.sum(err ** 2) / den) if den > 0 else np.nan
    return {"n": int(len(y_true)), "MAE_kN": mae, "RMSE_kN": rmse, "R2": r2}


def save_npz(path, X, y, input_end, target_time, feature_names):
    np.savez_compressed(
        path,
        X=np.asarray(X, dtype=np.float32),
        y=np.asarray(y, dtype=np.float32),
        input_end_time=np.asarray(input_end, dtype="U19"),
        target_time=np.asarray(target_time, dtype="U19"),
        feature_names=np.asarray(feature_names, dtype="U64"),
        window_hours=np.asarray(WINDOW_HOURS, dtype=np.int16),
        scenario=np.asarray("B_electrothermique_sans_force_passee", dtype="U64"),
    )


def format_date(v):
    if pd.isna(v):
        return "N/A"
    return pd.Timestamp(v).strftime("%Y-%m-%d %H:%M:%S")

# ============================================================================
# EXECUTION
# ============================================================================

def main():
    print("\n" + "=" * 76)
    print("CONSTRUCTION DU SCENARIO B - PREDICTION A t+1 HEURE")
    print("=" * 76)

    if not SERIES_FILE.exists():
        stop(
            "Fichier de serie auditee introuvable :\n"
            f"{SERIES_FILE}\n\n"
            "Place ce script dans le dossier qui contient le dossier "
            "resultats_prediction_t_plus_1h_modele_B, ou modifie SERIES_FILE "
            "dans la section CONFIGURATION UTILISATEUR."
        )
    if not SCENARIO_A_DATASET.exists():
        stop(
            "Jeu de donnees du Scenario A introuvable :\n"
            f"{SCENARIO_A_DATASET}\n"
            "Ce fichier est necessaire pour reprendre exactement les memes "
            "frontieres chronologiques."
        )

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    # 1. Chargement et controles de la serie source auditee.
    df = pd.read_csv(SERIES_FILE, low_memory=False)
    required = [TIMESTAMP_COLUMN, TARGET_COLUMN] + FEATURE_COLUMNS
    missing = [c for c in required if c not in df.columns]
    if missing:
        stop(f"Colonnes absentes de la serie auditee : {missing}")

    df = df[required].copy()
    # La serie est au format ISO YYYY-MM-DD HH:MM:SS : dayfirst=False.
    df[TIMESTAMP_COLUMN] = pd.to_datetime(
        df[TIMESTAMP_COLUMN], errors="coerce", yearfirst=True, dayfirst=False
    )
    if df[TIMESTAMP_COLUMN].isna().any():
        stop("Certaines dates de la serie auditee ne peuvent pas etre lues.")

    for c in FEATURE_COLUMNS + [TARGET_COLUMN]:
        df[c] = pd.to_numeric(df[c], errors="coerce")

    df = df.sort_values(TIMESTAMP_COLUMN).reset_index(drop=True)
    if df[TIMESTAMP_COLUMN].duplicated().any():
        dup = df.loc[df[TIMESTAMP_COLUMN].duplicated(), TIMESTAMP_COLUMN].head(10)
        stop("Horodatages dupliques detectes :\n" + dup.to_string(index=False))

    timestamps = pd.DatetimeIndex(df[TIMESTAMP_COLUMN])
    n_rows = len(df)
    one_hour_ns = pd.Timedelta(hours=1).value
    time_ns = timestamps.asi8
    X_source = df[FEATURE_COLUMNS].to_numpy(dtype=float)
    force_source = df[TARGET_COLUMN].to_numpy(dtype=float)

    # 2. Lire les bornes train/validation du Scenario A.
    a = pd.read_csv(
        SCENARIO_A_DATASET,
        usecols=["target_time_t_plus_1h", "partition"],
        low_memory=False,
    )
    a["target_time_t_plus_1h"] = pd.to_datetime(
        a["target_time_t_plus_1h"], errors="coerce", yearfirst=True, dayfirst=False
    )
    a["partition"] = a["partition"].astype(str).str.strip().str.lower()
    if a["target_time_t_plus_1h"].isna().any():
        stop("Dates invalides dans le fichier Scenario A.")
    if not {"train", "validation", "test"}.issubset(set(a["partition"])):
        stop("Le fichier Scenario A ne contient pas les trois partitions attendues.")

    train_end = a.loc[a["partition"] == "train", "target_time_t_plus_1h"].max()
    validation_end = a.loc[a["partition"] == "validation", "target_time_t_plus_1h"].max()
    if pd.isna(train_end) or pd.isna(validation_end) or train_end >= validation_end:
        stop("Impossible de determiner les limites chronologiques du Scenario A.")

    # 3. Construire les sequences strictement electrothermiques.
    # X : 24 heures x 9 variables. Y : force a t+1h.
    X_list, y_list = [], []
    input_end_list, target_time_list, force_t_list = [], [], []
    input_start_list = []
    excluded_gap = 0
    excluded_nan_X = 0
    excluded_nan_target = 0

    for i in range(WINDOW_HOURS - 1, n_rows - 1):
        start = i - WINDOW_HOURS + 1
        # Toutes les 24 mesures d'entree doivent etre strictement horaires.
        diffs = np.diff(time_ns[start:i + 1])
        if len(diffs) != WINDOW_HOURS - 1 or not np.all(diffs == one_hour_ns):
            excluded_gap += 1
            continue
        # La cible doit etre exactement une heure apres la derniere entree.
        if time_ns[i + 1] - time_ns[i] != one_hour_ns:
            excluded_gap += 1
            continue

        x_window = X_source[start:i + 1, :]
        if not np.isfinite(x_window).all():
            excluded_nan_X += 1
            continue

        y = force_source[i + 1]
        if not np.isfinite(y):
            excluded_nan_target += 1
            continue

        X_list.append(x_window)
        y_list.append(y)
        input_start_list.append(timestamps[start])
        input_end_list.append(timestamps[i])
        target_time_list.append(timestamps[i + 1])
        # Cette valeur sert uniquement a la reference de persistance.
        # Elle n'est jamais ajoutee a X.
        force_t_list.append(force_source[i])

    if not X_list:
        stop("Aucune sequence valide n'a ete construite.")

    X = np.asarray(X_list, dtype=np.float32)
    y = np.asarray(y_list, dtype=np.float32)
    input_start = pd.DatetimeIndex(input_start_list)
    input_end = pd.DatetimeIndex(input_end_list)
    target_time = pd.DatetimeIndex(target_time_list)
    force_t = np.asarray(force_t_list, dtype=float)

    # 4. Partitionnement avec les dates-limites exactes du Scenario A.
    train_mask = target_time <= train_end
    validation_mask = (target_time > train_end) & (target_time <= validation_end)
    test_mask = target_time > validation_end

    masks = {
        "train": train_mask,
        "validation": validation_mask,
        "test": test_mask,
    }
    if any(mask.sum() == 0 for mask in masks.values()):
        stop("Une partition du Scenario B est vide. Verifier les bornes temporelles.")

    # 5. Verifications anti-fuite et coherence temporelle.
    if X.shape[1:] != (WINDOW_HOURS, len(FEATURE_COLUMNS)):
        stop(f"Forme inattendue des tenseurs X : {X.shape}")
    if len(y) != len(target_time):
        stop("Incoherence entre le nombre de cibles et les horodatages.")
    if "F_clamp_kN" in FEATURE_COLUMNS or TARGET_COLUMN in FEATURE_COLUMNS:
        stop("ERREUR : la force mecanique est presente parmi les entrees.")

    # 6. Exporter le jeu complet tabulaire (216 variables d'entree).
    flat = {
        "input_start_time": input_start.strftime("%Y-%m-%d %H:%M:%S"),
        "input_end_time_t": input_end.strftime("%Y-%m-%d %H:%M:%S"),
        "target_time_t_plus_1h": target_time.strftime("%Y-%m-%d %H:%M:%S"),
        "F_target_t_plus_1h_kN": y,
        "partition": np.select(
            [train_mask, validation_mask, test_mask],
            ["train", "validation", "test"],
            default="unknown",
        ),
    }
    flat_feature_names = []
    for lag_index in range(WINDOW_HOURS):
        lag = WINDOW_HOURS - 1 - lag_index
        for j, feature in enumerate(FEATURE_COLUMNS):
            name = f"{feature}__lag_{lag}h"
            flat[name] = X[:, lag_index, j]
            flat_feature_names.append(name)

    full_df = pd.DataFrame(flat)
    full_csv = OUTPUT_DIR / "jeu_donnees_scenario_B_complet_t_plus_1h.csv"
    full_df.to_csv(full_csv, index=False, encoding="utf-8-sig")

    # CSV de chaque partition.
    for part, mask in masks.items():
        full_df.loc[mask].to_csv(
            OUTPUT_DIR / f"jeu_donnees_scenario_B_{part}_t_plus_1h.csv",
            index=False,
            encoding="utf-8-sig",
        )

    # Tenseurs NPZ globaux et par partition.
    save_npz(
        OUTPUT_DIR / "tenseurs_scenario_B_complet_t_plus_1h.npz",
        X, y, input_end.strftime("%Y-%m-%d %H:%M:%S"),
        target_time.strftime("%Y-%m-%d %H:%M:%S"), FEATURE_COLUMNS,
    )
    for part, mask in masks.items():
        save_npz(
            OUTPUT_DIR / f"tenseurs_scenario_B_{part}_t_plus_1h.npz",
            X[mask], y[mask], input_end[mask].strftime("%Y-%m-%d %H:%M:%S"),
            target_time[mask].strftime("%Y-%m-%d %H:%M:%S"), FEATURE_COLUMNS,
        )

    # 7. Resume des partitions.
    partition_rows = []
    for part, mask in masks.items():
        partition_rows.append({
            "partition": part,
            "n_observations": int(mask.sum()),
            "premiere_heure_debut_entree": format_date(input_start[mask][0]),
            "premiere_heure_fin_entree_t": format_date(input_end[mask][0]),
            "premiere_cible_t_plus_1h": format_date(target_time[mask][0]),
            "derniere_cible_t_plus_1h": format_date(target_time[mask][-1]),
            "force_courante_disponible_pour_baseline_n": int(np.isfinite(force_t[mask]).sum()),
        })
    partition_df = pd.DataFrame(partition_rows)
    partition_df.to_csv(OUTPUT_DIR / "resume_partitions_scenario_B.csv", index=False, encoding="utf-8-sig")

    # 8. Audit des variables et statistiques.
    variables_df = pd.DataFrame({
        "variable": FEATURE_COLUMNS,
        "role": ["entree_electrothermique"] * len(FEATURE_COLUMNS),
        "nombre_heures_par_sequence": [WINDOW_HOURS] * len(FEATURE_COLUMNS),
        "unite_declared_in_source": [
            "kV", "A", "degC", "degC", "degC", "degC", "degC", "degC", "degC"
        ],
        "valeurs_manquantes_source": [int(df[c].isna().sum()) for c in FEATURE_COLUMNS],
        "valeurs_min_source": [float(df[c].min()) if df[c].notna().any() else np.nan for c in FEATURE_COLUMNS],
        "valeurs_max_source": [float(df[c].max()) if df[c].notna().any() else np.nan for c in FEATURE_COLUMNS],
    })
    variables_df.to_csv(OUTPUT_DIR / "audit_variables_scenario_B.csv", index=False, encoding="utf-8-sig")

    # 9. Reference de persistance, calculee separement et jamais injectee dans X.
    baseline_rows = []
    baseline_detail = pd.DataFrame({
        "input_end_time_t": input_end.strftime("%Y-%m-%d %H:%M:%S"),
        "target_time_t_plus_1h": target_time.strftime("%Y-%m-%d %H:%M:%S"),
        "F_t_pour_baseline_uniquement_kN": force_t,
        "F_target_t_plus_1h_kN": y,
        "partition": np.select(
            [train_mask, validation_mask, test_mask],
            ["train", "validation", "test"], default="unknown"
        ),
    })
    baseline_detail["F_prediction_persistance_kN"] = baseline_detail["F_t_pour_baseline_uniquement_kN"]
    baseline_detail.to_csv(OUTPUT_DIR / "baseline_persistance_scenario_B_detail.csv", index=False, encoding="utf-8-sig")
    for part, mask in masks.items():
        met = metricas(y[mask], force_t[mask])
        baseline_rows.append({"partition": part, **met,
                              "couverture_baseline_pct": 100.0 * met["n"] / int(mask.sum())})
    baseline_df = pd.DataFrame(baseline_rows)
    baseline_df.to_csv(OUTPUT_DIR / "baseline_persistance_scenario_B.csv", index=False, encoding="utf-8-sig")

    # 10. Statistiques de la cible et correlations avec les variables a l'heure t.
    target_stats = pd.DataFrame([{
        "n": int(len(y)), "moyenne_F_cible_kN": float(np.mean(y)),
        "ecart_type_F_cible_kN": float(np.std(y, ddof=1)),
        "min_F_cible_kN": float(np.min(y)), "mediane_F_cible_kN": float(np.median(y)),
        "max_F_cible_kN": float(np.max(y)),
    }])
    target_stats.to_csv(OUTPUT_DIR / "statistiques_cible_scenario_B.csv", index=False, encoding="utf-8-sig")

    corr_rows = []
    for j, c in enumerate(FEATURE_COLUMNS):
        # Valeur la plus recente de chaque variable a l'instant t.
        v = X[:, -1, j].astype(float)
        corr = float(np.corrcoef(v, y)[0, 1]) if np.std(v) > 0 and np.std(y) > 0 else np.nan
        corr_rows.append({"variable_a_t": c, "correlation_pearson_avec_F_t_plus_1": corr})
    pd.DataFrame(corr_rows).sort_values(
        "correlation_pearson_avec_F_t_plus_1", key=lambda s: s.abs(), ascending=False
    ).to_csv(OUTPUT_DIR / "correlations_variables_t_cible_t_plus_1_scenario_B.csv", index=False, encoding="utf-8-sig")

    # 11. Audit d'integrite des sequences.
    audit_sequence = pd.DataFrame({
        "input_start_time": input_start.strftime("%Y-%m-%d %H:%M:%S"),
        "input_end_time_t": input_end.strftime("%Y-%m-%d %H:%M:%S"),
        "target_time_t_plus_1h": target_time.strftime("%Y-%m-%d %H:%M:%S"),
        "duree_historique_heures": [WINDOW_HOURS - 1] * len(y),
        "delai_cible_heures": [1] * len(y),
        "nombre_variables_entree": [len(FEATURE_COLUMNS)] * len(y),
        "force_passee_dans_X": [False] * len(y),
    })
    audit_sequence.to_csv(OUTPUT_DIR / "audit_integrite_sequences_scenario_B.csv", index=False, encoding="utf-8-sig")

    # 12. Rapport texte.
    lines = [
        "RAPPORT DE CONSTRUCTION - SCENARIO B ELECTROTHERMIQUE",
        "=" * 72,
        f"Fichier source : {SERIES_FILE}",
        f"Fichier Scenario A pour bornes : {SCENARIO_A_DATASET}",
        f"Nombre de lignes de serie auditee : {n_rows}",
        f"Premiere date source : {format_date(timestamps.min())}",
        f"Derniere date source : {format_date(timestamps.max())}",
        "",
        "DEFINITION EXPERIMENTALE",
        "- Entrees : 9 variables electrothermiques de t-23h a t.",
        "- Cible : force de serrage mesuree exactement a t+1h.",
        "- Force passee exclue des tenseurs X.",
        "- Pression de serrage exclue.",
        "- Aucune interpolation ni remplissage des heures manquantes.",
        "- Fenetres refusees si une heure manque ou si une entree est non finie.",
        "",
        "VARIABLES D'ENTREE :",
    ]
    lines += [f"  - {c}" for c in FEATURE_COLUMNS]
    lines += [
        "",
        "CONTROLES DE CONSTRUCTION",
        f"- Fenetres candidates examinees : {max(0, n_rows - WINDOW_HOURS)}",
        f"- Rejetees pour rupture horaire : {excluded_gap}",
        f"- Rejetees pour valeur manquante/non finie dans X : {excluded_nan_X}",
        f"- Rejetees pour cible F(t+1) manquante : {excluded_nan_target}",
        f"- Sequences valides : {len(y)}",
        f"- Forme du tenseur X : {X.shape} (N, 24, 9)",
        f"- Forme de la cible y : {y.shape}",
        "",
        "BORNES CHRONOLOGIQUES REPRISES DU SCENARIO A",
        f"- Fin train : {format_date(train_end)}",
        f"- Fin validation : {format_date(validation_end)}",
        "",
        "PARTITIONS SCENARIO B",
    ]
    for row in partition_rows:
        lines.append(
            f"- {row['partition']}: n={row['n_observations']}, "
            f"cibles {row['premiere_cible_t_plus_1h']} -> {row['derniere_cible_t_plus_1h']}"
        )
    lines += [
        "",
        "REFERENCE DE PERSISTANCE (F(t) -> F(t+1h))",
        "Note : F(t) est utilise uniquement pour cette baseline, pas comme entree du Scenario B.",
    ]
    for row in baseline_rows:
        lines.append(
            f"- {row['partition']}: n={row['n']}, MAE={row['MAE_kN']:.6f} kN, "
            f"RMSE={row['RMSE_kN']:.6f} kN, R2={row['R2']:.6f}, "
            f"couverture={row['couverture_baseline_pct']:.2f}%"
        )
    lines += [
        "",
        "INTERPRETATION",
        "Le Scenario B permet d'evaluer la prediction a t+1h a partir des seules "
        "informations electrothermiques. La mesure F(t) n'est pas un predicteur.",
        "La baseline de persistance est fournie a titre de comparaison separee.",
        "Les partitions conservent les memes bornes temporelles que le Scenario A.",
        "",
        "FICHIERS PRINCIPAUX",
        "- jeu_donnees_scenario_B_complet_t_plus_1h.csv",
        "- jeu_donnees_scenario_B_train_t_plus_1h.csv",
        "- jeu_donnees_scenario_B_validation_t_plus_1h.csv",
        "- jeu_donnees_scenario_B_test_t_plus_1h.csv",
        "- tenseurs_scenario_B_[complet/train/validation/test]_t_plus_1h.npz",
        "- baseline_persistance_scenario_B.csv",
        "- audit_variables_scenario_B.csv",
        "- audit_integrite_sequences_scenario_B.csv",
    ]
    (OUTPUT_DIR / "RAPPORT_SCENARIO_B_ELECTROTHERMIQUE_t_plus_1h.txt").write_text(
        "\n".join(lines), encoding="utf-8"
    )

    # 13. Graphiques facultatifs.
    try:
        import matplotlib.pyplot as plt
        graph_dir = OUTPUT_DIR / "graphiques"
        graph_dir.mkdir(exist_ok=True)

        fig, ax = plt.subplots(figsize=(12, 4))
        ax.plot(target_time, y, linewidth=0.8)
        ax.set_title("Scenario B - Force cible a t+1h")
        ax.set_xlabel("Date cible")
        ax.set_ylabel("Force de serrage (kN)")
        ax.grid(True, alpha=0.25)
        fig.tight_layout()
        fig.savefig(graph_dir / "force_cible_scenario_B.png", dpi=150)
        plt.close(fig)

        fig, ax = plt.subplots(figsize=(8, 4))
        ax.bar(baseline_df["partition"], baseline_df["RMSE_kN"])
        ax.set_title("Baseline de persistance - Scenario B")
        ax.set_ylabel("RMSE (kN)")
        ax.grid(axis="y", alpha=0.25)
        fig.tight_layout()
        fig.savefig(graph_dir / "baseline_persistance_scenario_B.png", dpi=150)
        plt.close(fig)
    except Exception as exc:
        print(f"Graphiques non generes (optionnel) : {exc}")

    # 14. Resume console.
    print("\n" + "=" * 76)
    print("CONSTRUCTION DU SCENARIO B TERMINEE")
    print("=" * 76)
    print(f"Dossier : {OUTPUT_DIR}")
    print(f"Sequences valides : {len(y)} | X={X.shape}")
    print(f"Train={int(train_mask.sum())} | Validation={int(validation_mask.sum())} | Test={int(test_mask.sum())}")
    print("\nBaseline de persistance (F(t) -> F(t+1h), hors entrees du Scenario B) :")
    print(baseline_df.to_string(index=False))
    print("\nOuvre d'abord RAPPORT_SCENARIO_B_ELECTROTHERMIQUE_t_plus_1h.txt")
    print("Puis compresse tout le dossier de resultats et transmets-le pour analyse.")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print("\nERREUR :", exc)
        raise
