# -*- coding: utf-8 -*-
"""
Created on Sun Nov  1 23:47:05 2026

@author: Leni
"""

# -*- coding: utf-8 -*-
"""
SCENARIO C — PREDIRE LA VARIATION DE FORCE DE SERRAGE A t+1 HEURE

Formulation :
    Delta_F(t+1) = F(t+1) - F(t)
    Delta_F_hat(t+1) = modele(sequence electrothermique sur 24 h)
    F_hat(t+1) = F(t) + Delta_F_hat(t+1)

Les entrees du modele sont exclusivement les 9 variables electrothermiques
sur les 24 heures t-23 h ... t. F(t) sert UNIQUEMENT d'origine pour
reconstruire la force predite ; elle n'est jamais incluse dans X.

Le code apparie les dates des scenarios A et B :
- Scenario B fournit les sequences X electrothermiques.
- Scenario A fournit F(t), cible F(t+1), et les metadonnees de partition.
Les observations sont apparies par target_time_t_plus_1h.

Architectures : Ridge, Random Forest, XGBoost, SVR-RBF, MLP, LSTM, GRU.
Selection hyperparametres sur validation ; test final garde a part.
"""


import copy
import json
import random
import time
import warnings
from pathlib import Path

import joblib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import torch
from torch import nn
from torch.utils.data import DataLoader, TensorDataset

from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import Ridge
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVR

try:
    from xgboost import XGBRegressor
except Exception as exc:
    raise ImportError(
        "XGBoost est requis pour cette comparaison. Installe-le avec : pip install xgboost"
    ) from exc


# =============================================================================
# 1. CONFIGURATION UTILISATEUR
# =============================================================================

# Répertoire racine du projet
PROJECT_DIR = Path(__file__).resolve().parent.parent

# Dossiers des jeux de données A et B
SCENARIO_A_DIR = PROJECT_DIR / "resultats_prediction_t_plus_1h_modele_B"
SCENARIO_B_DIR = PROJECT_DIR / "resultats_scenario_B_electrothermique_t_plus_1h"

# Fichiers d'entrée
SCENARIO_A_FILE = "jeu_donnees_dynamique_complet_t_plus_1h.csv"
SCENARIO_B_FILE = "jeu_donnees_scenario_B_complet_t_plus_1h.csv"

# Dossier de sortie du scénario C
OUTPUT_DIR = PROJECT_DIR / "resultats_scenario_C_variation_force_t_plus_1h"

WINDOW_HOURS = 24
TARGET_TIME_COLUMN = "target_time_t_plus_1h"
INPUT_END_COLUMN = "input_end_time_t"
TARGET_COLUMN = "F_target_t_plus_1h_kN"
PARTITION_COLUMN = "partition"
BASELINE_A_COLUMN = "F_t_kN_baseline"
MECHANICAL_LAG_ZERO_COLUMN = "F_clamp_kN_history__lag_0h"

THERMAL_ELECTRICAL_FEATURES = [
    "Voltage [kV]",
    "Current [A]",
    "Ambient [degC]",
    "Top oil [degC]",
    "Bottom oil [degC]",
    "Mid-spot HV [degC]",
    "Mid-spot LV [degC]",
    "Hot-spot HV [degC]",
    "Hot-spot LV [degC]",
]

RANDOM_SEED = 42
N_JOBS = -1
RF_N_ESTIMATORS = 350
XGB_MAX_ESTIMATORS = 700
XGB_EARLY_STOPPING_ROUNDS = 35
SVR_MAX_ITER = -1

TORCH_MAX_EPOCHS = 100
TORCH_PATIENCE = 12
TORCH_BATCH_SIZE = 128
TORCH_LEARNING_RATE = 1e-3
TORCH_WEIGHT_DECAY = 1e-4
TORCH_NUM_WORKERS = 0

# True = essai technique rapide seulement. Laisser False pour l'experience complete.
SMOKE_TEST = False

# Pour la comparaison A/B/C, on garde uniquement les horodatages communs A et B.
USE_COMMON_A_B_TIMESTAMPS = True


# =============================================================================
# 2. OUTILS GENERAUX
# =============================================================================

def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def make_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def parse_datetime(series: pd.Series, label: str) -> pd.Series:
    out = pd.to_datetime(series, errors="coerce", yearfirst=True)
    if out.isna().any():
        examples = series[out.isna()].head(5).tolist()
        raise ValueError(f"Dates invalides dans {label}: {examples}")
    return out


def json_text(obj) -> str:
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, default=str)


def regression_metrics(y_true, y_pred, prefix="") -> dict:
    yt = np.asarray(y_true, dtype=float).reshape(-1)
    yp = np.asarray(y_pred, dtype=float).reshape(-1)
    err = yp - yt
    abs_err = np.abs(err)
    return {
        f"{prefix}n": int(len(yt)),
        f"{prefix}MAE_kN": float(mean_absolute_error(yt, yp)),
        f"{prefix}RMSE_kN": float(np.sqrt(mean_squared_error(yt, yp))),
        f"{prefix}R2": float(r2_score(yt, yp)) if len(yt) > 1 else np.nan,
        f"{prefix}Biais_moyen_kN": float(np.mean(err)),
        f"{prefix}Erreur_absolue_P95_kN": float(np.quantile(abs_err, 0.95)),
        f"{prefix}Erreur_absolue_max_kN": float(np.max(abs_err)),
    }


def standardize_X_fit(X_train: np.ndarray, X_other: np.ndarray):
    n_features = X_train.shape[2]
    scaler = StandardScaler()
    scaler.fit(X_train.reshape(-1, n_features))
    Xtr = scaler.transform(X_train.reshape(-1, n_features)).reshape(X_train.shape).astype(np.float32)
    Xot = scaler.transform(X_other.reshape(-1, n_features)).reshape(X_other.shape).astype(np.float32)
    return Xtr, Xot, scaler


def standardize_X_transform(X: np.ndarray, scaler: StandardScaler):
    n_features = X.shape[2]
    return scaler.transform(X.reshape(-1, n_features)).reshape(X.shape).astype(np.float32)


def standardize_y_fit(y_train: np.ndarray):
    scaler = StandardScaler()
    ys = scaler.fit_transform(np.asarray(y_train).reshape(-1, 1)).reshape(-1).astype(np.float32)
    return ys, scaler


def inverse_y(y_scaled: np.ndarray, scaler: StandardScaler):
    return scaler.inverse_transform(np.asarray(y_scaled).reshape(-1, 1)).reshape(-1)


# =============================================================================
# 3. CHARGEMENT, APPARIEMENT ET CONSTRUCTION DE DELTA F
# =============================================================================

def load_and_align_scenarios():
    path_a = SCENARIO_A_DIR / SCENARIO_A_FILE
    path_b = SCENARIO_B_DIR / SCENARIO_B_FILE
    if not path_a.exists():
        raise FileNotFoundError(f"Fichier Scenario A introuvable : {path_a}")
    if not path_b.exists():
        raise FileNotFoundError(f"Fichier Scenario B introuvable : {path_b}")

    print("Lecture des scenarios A et B...")
    a = pd.read_csv(path_a, low_memory=False)
    b = pd.read_csv(path_b, low_memory=False)

    required_common = [TARGET_TIME_COLUMN, INPUT_END_COLUMN, TARGET_COLUMN, PARTITION_COLUMN]
    for label, df in [("A", a), ("B", b)]:
        missing = [c for c in required_common if c not in df.columns]
        if missing:
            raise ValueError(f"Colonnes manquantes dans Scenario {label}: {missing}")
        df[TARGET_TIME_COLUMN] = parse_datetime(df[TARGET_TIME_COLUMN], f"{label}.{TARGET_TIME_COLUMN}")
        df[INPUT_END_COLUMN] = parse_datetime(df[INPUT_END_COLUMN], f"{label}.{INPUT_END_COLUMN}")
        df[TARGET_COLUMN] = pd.to_numeric(df[TARGET_COLUMN], errors="coerce")
        df[PARTITION_COLUMN] = df[PARTITION_COLUMN].astype(str).str.strip().str.lower()
        if df[TARGET_TIME_COLUMN].duplicated().any():
            raise ValueError(f"Dates cibles dupliquees dans Scenario {label}.")
        if df[TARGET_COLUMN].isna().any():
            raise ValueError(f"Cibles manquantes/non numeriques dans Scenario {label}.")
        delta_t = df[TARGET_TIME_COLUMN] - df[INPUT_END_COLUMN]
        if not (delta_t == pd.Timedelta(hours=1)).all():
            raise ValueError(f"Le lien t -> t+1 h est incorrect dans Scenario {label}.")

    # Force a t : colonne baseline explicite, sinon lag 0 de la memoire mecanique A.
    if BASELINE_A_COLUMN in a.columns:
        force_t_col = BASELINE_A_COLUMN
        force_t_source = BASELINE_A_COLUMN
    elif MECHANICAL_LAG_ZERO_COLUMN in a.columns:
        force_t_col = MECHANICAL_LAG_ZERO_COLUMN
        force_t_source = MECHANICAL_LAG_ZERO_COLUMN
    else:
        raise ValueError(
            "Impossible de retrouver F(t) dans Scenario A. Colonnes attendues : "
            f"'{BASELINE_A_COLUMN}' ou '{MECHANICAL_LAG_ZERO_COLUMN}'."
        )
    a[force_t_col] = pd.to_numeric(a[force_t_col], errors="coerce")

    # Scenario B doit contenir strictement les 9 variables electrothermiques.
    feature_cols = []
    for lag in range(WINDOW_HOURS - 1, -1, -1):
        for base in THERMAL_ELECTRICAL_FEATURES:
            col = f"{base}__lag_{lag}h"
            if col not in b.columns:
                raise ValueError(f"Variable B manquante : {col}")
            feature_cols.append(col)

    # Verification de l'absence de colonnes mecaniques dans la matrice d'entree B.
    forbidden = [c for c in feature_cols if "clamp" in c.lower() or "force" in c.lower()]
    if forbidden:
        raise ValueError(f"Variables mecaniques detectees dans les entrees B : {forbidden}")

    a_meta_cols = [TARGET_TIME_COLUMN, INPUT_END_COLUMN, TARGET_COLUMN, PARTITION_COLUMN, force_t_col]
    a_meta = a[a_meta_cols].copy().rename(columns={force_t_col: "F_t_kN"})
    b_cols = [TARGET_TIME_COLUMN, INPUT_END_COLUMN, TARGET_COLUMN, PARTITION_COLUMN] + feature_cols
    b_model = b[b_cols].copy()

    merged = pd.merge(
        a_meta, b_model,
        on=TARGET_TIME_COLUMN,
        how="inner",
        suffixes=("_A", "_B"),
        validate="one_to_one",
    )
    if merged.empty:
        raise ValueError("Aucun horodatage cible commun entre A et B.")

    # Verifier l'identite des cibles, partitions et instants t.
    if not np.allclose(
        merged[f"{TARGET_COLUMN}_A"].to_numpy(dtype=float),
        merged[f"{TARGET_COLUMN}_B"].to_numpy(dtype=float),
        rtol=0.0, atol=1e-5,
    ):
        raise ValueError("F(t+1) differe entre A et B aux dates communes.")
    if not (merged[f"{PARTITION_COLUMN}_A"] == merged[f"{PARTITION_COLUMN}_B"]).all():
        raise ValueError("Les partitions A et B ne correspondent pas.")
    if not (merged[f"{INPUT_END_COLUMN}_A"] == merged[f"{INPUT_END_COLUMN}_B"]).all():
        raise ValueError("Les instants d'entree t different entre A et B.")

    merged[TARGET_TIME_COLUMN] = parse_datetime(merged[TARGET_TIME_COLUMN], TARGET_TIME_COLUMN)
    merged["input_end_time_t"] = merged[f"{INPUT_END_COLUMN}_A"]
    merged["F_target_t_plus_1h_kN"] = merged[f"{TARGET_COLUMN}_A"].astype(float)
    merged["partition"] = merged[f"{PARTITION_COLUMN}_A"].astype(str)
    merged["F_t_kN"] = pd.to_numeric(merged["F_t_kN"], errors="coerce")

    # Verifier F(t) disponible. Aucun remplacement/interpolation de la force.
    missing_force_by_partition = (
        merged.loc[merged["F_t_kN"].isna()]
        .groupby("partition").size().to_dict()
    )
    n_before = len(merged)
    merged = merged.dropna(subset=["F_t_kN"]).copy()
    n_dropped_force_t = n_before - len(merged)
    merged = merged.sort_values(TARGET_TIME_COLUMN).reset_index(drop=True)

    # Cible delta, et non force absolue.
    merged["delta_F_target_kN"] = merged["F_target_t_plus_1h_kN"] - merged["F_t_kN"]

    x = merged[feature_cols].apply(pd.to_numeric, errors="coerce").to_numpy(dtype=np.float32)
    if not np.isfinite(x).all():
        bad = int((~np.isfinite(x)).sum())
        raise ValueError(f"{bad} valeurs non finies dans les entrees electrothermiques B.")
    X = x.reshape(len(merged), WINDOW_HOURS, len(THERMAL_ELECTRICAL_FEATURES))

    # Audit explicite : F(t) est offset de reconstruction, jamais feature.
    if X.shape[2] != 9:
        raise ValueError(f"Nombre de variables incorrect pour C : {X.shape[2]} au lieu de 9.")
    if not np.allclose(
        merged["F_t_kN"].to_numpy() + merged["delta_F_target_kN"].to_numpy(),
        merged["F_target_t_plus_1h_kN"].to_numpy(),
        rtol=0.0, atol=1e-8,
    ):
        raise AssertionError("L'identite F(t) + DeltaF = F(t+1) n'est pas respectee.")

    partitions = {}
    for part in ["train", "validation", "test"]:
        idx = np.flatnonzero(merged["partition"].to_numpy() == part)
        if len(idx) == 0:
            raise ValueError(f"Partition vide : {part}")
        partitions[part] = {
            "X": X[idx],
            "delta": merged.iloc[idx]["delta_F_target_kN"].to_numpy(dtype=np.float32),
            "F_t": merged.iloc[idx]["F_t_kN"].to_numpy(dtype=np.float32),
            "F_target": merged.iloc[idx]["F_target_t_plus_1h_kN"].to_numpy(dtype=np.float32),
            "meta": merged.iloc[idx][[TARGET_TIME_COLUMN, "input_end_time_t", "partition", "F_t_kN", "F_target_t_plus_1h_kN", "delta_F_target_kN"]].reset_index(drop=True),
        }

    # Audit des effectifs et dates par partition.
    audit_rows = []
    for part in ["train", "validation", "test"]:
        sub = merged[merged["partition"] == part]
        audit_rows.append({
            "partition": part,
            "n_sequences": len(sub),
            "date_cible_debut": sub[TARGET_TIME_COLUMN].min(),
            "date_cible_fin": sub[TARGET_TIME_COLUMN].max(),
            "F_t_manquante_exclue": int(missing_force_by_partition.get(part, 0)),
            "delta_F_moyenne_kN": sub["delta_F_target_kN"].mean(),
            "delta_F_ecart_type_kN": sub["delta_F_target_kN"].std(),
        })

    # Donnees de metadonnees completes pour livrable/audit.
    meta_export = merged[[
        TARGET_TIME_COLUMN, "input_end_time_t", "partition", "F_t_kN",
        "F_target_t_plus_1h_kN", "delta_F_target_kN"
    ]].copy()
    meta_export.to_csv(OUTPUT_DIR / "donnees_cibles_scenario_C.csv", index=False, encoding="utf-8-sig")

    # Sauvegarder aussi les jeux X/y, sans colonnes mecaniques dans X.
    np.savez_compressed(
        OUTPUT_DIR / "jeu_donnees_scenario_C_t_plus_1h.npz",
        X=X.astype(np.float32),
        delta_F=merged["delta_F_target_kN"].to_numpy(dtype=np.float32),
        F_t=merged["F_t_kN"].to_numpy(dtype=np.float32),
        F_target=merged["F_target_t_plus_1h_kN"].to_numpy(dtype=np.float32),
        target_time=merged[TARGET_TIME_COLUMN].astype(str).to_numpy(),
        partition=merged["partition"].astype(str).to_numpy(),
        feature_names=np.array(THERMAL_ELECTRICAL_FEATURES, dtype=object),
    )

    full_export = merged[[TARGET_TIME_COLUMN, "input_end_time_t", "partition", "F_t_kN", "F_target_t_plus_1h_kN", "delta_F_target_kN"] + feature_cols].copy()
    full_export.to_csv(OUTPUT_DIR / "jeu_donnees_scenario_C_complet.csv", index=False, encoding="utf-8-sig")

    return partitions, merged, pd.DataFrame(audit_rows), force_t_source, n_dropped_force_t


# =============================================================================
# 4. ARCHITECTURES CLASSIQUES
# =============================================================================

def classical_grid(smoke=False):
    if smoke:
        return {
            "Ridge": [{"alpha": 1.0}],
            "RandomForest": [{"max_depth": 14, "min_samples_leaf": 2, "max_features": 1.0}],
            "XGBoost": [{"max_depth": 3, "learning_rate": 0.04, "subsample": 0.9, "colsample_bytree": 0.9, "reg_lambda": 5.0}],
            "SVR": [{"C": 10.0, "epsilon": 0.05, "gamma": "scale"}],
        }
    return {
        "Ridge": [{"alpha": 0.1}, {"alpha": 1.0}, {"alpha": 10.0}, {"alpha": 100.0}],
        "RandomForest": [
            {"max_depth": None, "min_samples_leaf": 1, "max_features": 1.0},
            {"max_depth": 16, "min_samples_leaf": 2, "max_features": 1.0},
        ],
        "XGBoost": [
            {"max_depth": 2, "learning_rate": 0.03, "subsample": 0.9, "colsample_bytree": 0.9, "reg_lambda": 5.0},
            {"max_depth": 3, "learning_rate": 0.04, "subsample": 0.9, "colsample_bytree": 0.9, "reg_lambda": 5.0},
        ],
        "SVR": [
            {"C": 10.0, "epsilon": 0.05, "gamma": "scale"},
            {"C": 50.0, "epsilon": 0.05, "gamma": "scale"},
        ],
    }


def make_xgb(params, n_estimators, use_early_stopping):
    kwargs = dict(
        objective="reg:squarederror",
        n_estimators=int(n_estimators),
        max_depth=int(params["max_depth"]),
        learning_rate=float(params["learning_rate"]),
        subsample=float(params["subsample"]),
        colsample_bytree=float(params["colsample_bytree"]),
        reg_lambda=float(params["reg_lambda"]),
        random_state=RANDOM_SEED,
        n_jobs=N_JOBS,
        tree_method="hist",
        eval_metric="rmse",
        verbosity=0,
    )
    if use_early_stopping:
        kwargs["early_stopping_rounds"] = XGB_EARLY_STOPPING_ROUNDS
    return XGBRegressor(**kwargs)


def fit_classical_candidate(name, params, Xtr, ytr_s, Xval, yval_s):
    Xtr_flat = Xtr.reshape(len(Xtr), -1)
    Xval_flat = Xval.reshape(len(Xval), -1)
    best_rounds = None
    if name == "Ridge":
        model = Ridge(alpha=float(params["alpha"]))
        model.fit(Xtr_flat, ytr_s)
    elif name == "RandomForest":
        model = RandomForestRegressor(
            n_estimators=RF_N_ESTIMATORS,
            max_depth=params["max_depth"],
            min_samples_leaf=int(params["min_samples_leaf"]),
            max_features=params["max_features"],
            random_state=RANDOM_SEED,
            n_jobs=N_JOBS,
        )
        model.fit(Xtr_flat, ytr_s)
    elif name == "XGBoost":
        model = make_xgb(params, XGB_MAX_ESTIMATORS, True)
        model.fit(Xtr_flat, ytr_s, eval_set=[(Xval_flat, yval_s)], verbose=False)
        best_rounds = int(getattr(model, "best_iteration", XGB_MAX_ESTIMATORS - 1)) + 1
    elif name == "SVR":
        model = SVR(kernel="rbf", C=float(params["C"]), epsilon=float(params["epsilon"]),
                    gamma=params["gamma"], cache_size=1000, max_iter=SVR_MAX_ITER, tol=1e-3)
        model.fit(Xtr_flat, ytr_s)
    else:
        raise ValueError(name)
    return model, best_rounds


# =============================================================================
# 5. ARCHITECTURES NEURONALES
# =============================================================================

class MLPNetwork(nn.Module):
    def __init__(self, n_inputs, hidden, dropout):
        super().__init__()
        layers = []
        prev = n_inputs
        for width in hidden:
            layers += [nn.Linear(prev, int(width)), nn.ReLU(), nn.Dropout(float(dropout))]
            prev = int(width)
        layers.append(nn.Linear(prev, 1))
        self.net = nn.Sequential(*layers)

    def forward(self, x):
        return self.net(x.reshape(x.shape[0], -1)).squeeze(-1)


class RecurrentNetwork(nn.Module):
    def __init__(self, n_features, hidden_size, kind, dropout):
        super().__init__()
        rnn_cls = nn.LSTM if kind == "LSTM" else nn.GRU
        self.drop_in = nn.Dropout(float(dropout))
        self.rnn = rnn_cls(input_size=n_features, hidden_size=int(hidden_size), batch_first=True)
        mid = max(16, int(hidden_size) // 2)
        self.head = nn.Sequential(nn.Dropout(float(dropout)), nn.Linear(int(hidden_size), mid), nn.ReLU(), nn.Linear(mid, 1))

    def forward(self, x):
        seq, _ = self.rnn(self.drop_in(x))
        return self.head(seq[:, -1, :]).squeeze(-1)


def make_neural(name, n_features, params):
    if name == "MLP":
        return MLPNetwork(n_features * WINDOW_HOURS, params["hidden"], params.get("dropout", 0.15))
    if name in ("LSTM", "GRU"):
        return RecurrentNetwork(n_features, params["hidden_size"], name, params.get("dropout", 0.15))
    raise ValueError(name)


def predict_neural(model, X, device):
    model.eval()
    chunks = []
    with torch.no_grad():
        for start in range(0, len(X), 512):
            xb = torch.as_tensor(X[start:start + 512], dtype=torch.float32, device=device)
            chunks.append(model(xb).detach().cpu().numpy().reshape(-1))
    return np.concatenate(chunks) if chunks else np.array([], dtype=float)


def neural_grid(smoke=False):
    if smoke:
        return {
            "MLP": [{"hidden": [64, 32], "dropout": 0.10}],
            "LSTM": [{"hidden_size": 32, "dropout": 0.10}],
            "GRU": [{"hidden_size": 32, "dropout": 0.10}],
        }
    return {
        "MLP": [
            {"hidden": [128, 64], "dropout": 0.15},
            {"hidden": [256, 128], "dropout": 0.15},
        ],
        "LSTM": [
            {"hidden_size": 32, "dropout": 0.15},
            {"hidden_size": 64, "dropout": 0.15},
        ],
        "GRU": [
            {"hidden_size": 32, "dropout": 0.15},
            {"hidden_size": 64, "dropout": 0.15},
        ],
    }


def train_neural_candidate(name, params, Xtr, ytr_s, Xval, yval_s, seed):
    set_seed(seed)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    model = make_neural(name, Xtr.shape[2], params).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=TORCH_LEARNING_RATE, weight_decay=TORCH_WEIGHT_DECAY)
    loss_fn = nn.MSELoss()
    ds = TensorDataset(torch.as_tensor(Xtr, dtype=torch.float32), torch.as_tensor(ytr_s, dtype=torch.float32))
    loader = DataLoader(ds, batch_size=TORCH_BATCH_SIZE, shuffle=True, num_workers=TORCH_NUM_WORKERS)
    xv = torch.as_tensor(Xval, dtype=torch.float32, device=device)
    yv = np.asarray(yval_s, dtype=float)

    best_rmse = np.inf
    best_epoch = 1
    best_state = None
    patience_count = 0
    for epoch in range(1, TORCH_MAX_EPOCHS + 1):
        model.train()
        for xb_cpu, yb_cpu in loader:
            xb, yb = xb_cpu.to(device), yb_cpu.to(device)
            optimizer.zero_grad(set_to_none=True)
            pred = model(xb)
            loss = loss_fn(pred, yb)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=2.0)
            optimizer.step()
        pred_val = predict_neural(model, Xval, device)
        rmse = float(np.sqrt(mean_squared_error(yv, pred_val)))
        if rmse < best_rmse - 1e-6:
            best_rmse = rmse
            best_epoch = epoch
            best_state = copy.deepcopy(model.state_dict())
            patience_count = 0
        else:
            patience_count += 1
        if patience_count >= TORCH_PATIENCE:
            break
    if best_state is not None:
        model.load_state_dict(best_state)
    return model, best_epoch, best_rmse


def train_neural_fixed(name, params, Xtrainval, ytrainval_s, epochs, seed):
    set_seed(seed)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    model = make_neural(name, Xtrainval.shape[2], params).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=TORCH_LEARNING_RATE, weight_decay=TORCH_WEIGHT_DECAY)
    loss_fn = nn.MSELoss()
    ds = TensorDataset(torch.as_tensor(Xtrainval, dtype=torch.float32), torch.as_tensor(ytrainval_s, dtype=torch.float32))
    loader = DataLoader(ds, batch_size=TORCH_BATCH_SIZE, shuffle=True, num_workers=TORCH_NUM_WORKERS)
    for _ in range(max(1, int(epochs))):
        model.train()
        for xb_cpu, yb_cpu in loader:
            xb, yb = xb_cpu.to(device), yb_cpu.to(device)
            optimizer.zero_grad(set_to_none=True)
            loss = loss_fn(model(xb), yb)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=2.0)
            optimizer.step()
    return model, device


# =============================================================================
# 6. ENTRAINEMENT ET SELECTION SUR VALIDATION
# =============================================================================

def run_experiment(partitions):
    out_scenario = OUTPUT_DIR / "Scenario_C"
    model_dir = out_scenario / "modeles"
    make_dir(model_dir)

    tr = partitions["train"]
    va = partitions["validation"]
    te = partitions["test"]

    Xtr_s, Xva_s, x_scaler_sel = standardize_X_fit(tr["X"], va["X"])
    ytr_s, y_scaler_sel = standardize_y_fit(tr["delta"])
    yva_s = y_scaler_sel.transform(va["delta"].reshape(-1, 1)).reshape(-1).astype(np.float32)

    classic = classical_grid(SMOKE_TEST)
    neural = neural_grid(SMOKE_TEST)
    selected = {}
    search_rows = []

    print("\n" + "=" * 78)
    print("ENTRAINEMENT DU SCENARIO C — CIBLE DELTA F")
    print("=" * 78)

    # Modeles classiques : la selection est faite sur l'erreur de force reconstruite.
    for name in ["Ridge", "RandomForest", "XGBoost", "SVR"]:
        best = None
        for ci, params in enumerate(classic[name], start=1):
            tic = time.time()
            print(f"[C] {name} candidat {ci}/{len(classic[name])}: {params}")
            model, best_rounds = fit_classical_candidate(name, params, Xtr_s, ytr_s, Xva_s, yva_s)
            delta_pred_scaled = model.predict(Xva_s.reshape(len(Xva_s), -1))
            delta_pred = inverse_y(delta_pred_scaled, y_scaler_sel)
            force_pred = va["F_t"] + delta_pred
            met_force = regression_metrics(va["F_target"], force_pred)
            met_delta = regression_metrics(va["delta"], delta_pred, prefix="delta_")
            row = {
                "architecture": name,
                "candidat": ci,
                "parametres": json_text(params),
                "best_rounds_XGBoost": best_rounds,
                "temps_selection_s": time.time() - tic,
                **met_force,
                **met_delta,
            }
            search_rows.append(row)
            if best is None or met_force["RMSE_kN"] < best["validation_RMSE_force_kN"]:
                best = {"params": params, "validation_RMSE_force_kN": met_force["RMSE_kN"], "best_rounds": best_rounds}
        selected[name] = best
        print(f"  -> retenu : RMSE force validation={best['validation_RMSE_force_kN']:.5f} kN | {best['params']}")

    # MLP / LSTM / GRU : RMSE delta et RMSE force ont les memes residus ici.
    for name in ["MLP", "LSTM", "GRU"]:
        best = None
        for ci, params in enumerate(neural[name], start=1):
            tic = time.time()
            print(f"[C] {name} candidat {ci}/{len(neural[name])}: {params}")
            model, best_epoch, val_rmse_scaled = train_neural_candidate(
                name, params, Xtr_s, ytr_s, Xva_s, yva_s, RANDOM_SEED + ci
            )
            device = "cuda" if torch.cuda.is_available() else "cpu"
            delta_pred_scaled = predict_neural(model, Xva_s, device)
            delta_pred = inverse_y(delta_pred_scaled, y_scaler_sel)
            force_pred = va["F_t"] + delta_pred
            met_force = regression_metrics(va["F_target"], force_pred)
            met_delta = regression_metrics(va["delta"], delta_pred, prefix="delta_")
            row = {
                "architecture": name,
                "candidat": ci,
                "parametres": json_text(params),
                "best_epoch": int(best_epoch),
                "temps_selection_s": time.time() - tic,
                **met_force,
                **met_delta,
            }
            search_rows.append(row)
            if best is None or met_force["RMSE_kN"] < best["validation_RMSE_force_kN"]:
                best = {"params": params, "validation_RMSE_force_kN": met_force["RMSE_kN"], "best_epoch": int(best_epoch)}
        selected[name] = best
        print(f"  -> retenu : RMSE force validation={best['validation_RMSE_force_kN']:.5f} kN | {best['params']} | epochs={best.get('best_epoch')}")

    # Refit final : train + validation. Test n'est jamais utilise pour selection.
    Xtv = np.concatenate([tr["X"], va["X"]], axis=0)
    dtv = np.concatenate([tr["delta"], va["delta"]], axis=0)
    Xtv_s, Xte_s, x_scaler_final = standardize_X_fit(Xtv, te["X"])
    dtv_s, y_scaler_final = standardize_y_fit(dtv)

    predictions = {}
    final_infos = {}

    for name in ["Ridge", "RandomForest", "XGBoost", "SVR"]:
        cfg = selected[name]
        Xflat = Xtv_s.reshape(len(Xtv_s), -1)
        if name == "Ridge":
            model = Ridge(alpha=float(cfg["params"]["alpha"]))
        elif name == "RandomForest":
            p = cfg["params"]
            model = RandomForestRegressor(
                n_estimators=RF_N_ESTIMATORS,
                max_depth=p["max_depth"],
                min_samples_leaf=int(p["min_samples_leaf"]),
                max_features=p["max_features"],
                random_state=RANDOM_SEED, n_jobs=N_JOBS,
            )
        elif name == "XGBoost":
            model = make_xgb(cfg["params"], cfg.get("best_rounds") or XGB_MAX_ESTIMATORS, False)
        else:
            p = cfg["params"]
            model = SVR(kernel="rbf", C=float(p["C"]), epsilon=float(p["epsilon"]),
                        gamma=p["gamma"], cache_size=1000, max_iter=SVR_MAX_ITER, tol=1e-3)
        model.fit(Xflat, dtv_s)
        delta_pred_scaled = model.predict(Xte_s.reshape(len(Xte_s), -1))
        delta_pred = inverse_y(delta_pred_scaled, y_scaler_final)
        force_pred = te["F_t"] + delta_pred
        predictions[name] = {"delta": delta_pred, "force": force_pred}
        joblib.dump({
            "model": model,
            "x_scaler": x_scaler_final,
            "delta_scaler": y_scaler_final,
            "feature_names_per_hour": THERMAL_ELECTRICAL_FEATURES,
            "window_hours": WINDOW_HOURS,
            "target": "Delta_F(t+1h) = F(t+1h) - F(t)",
            "reconstruction": "F_hat(t+1h) = measured_F(t) + predicted_Delta_F(t+1h)",
            "scenario": "C",
            "params": cfg["params"],
        }, model_dir / f"{name}_scenario_C.joblib")
        final_infos[name] = {
            "params": cfg["params"],
            "validation_RMSE_force_kN": cfg["validation_RMSE_force_kN"],
        }
        print(f"[C] {name} finalise.")

    for name in ["MLP", "LSTM", "GRU"]:
        cfg = selected[name]
        model, device = train_neural_fixed(
            name, cfg["params"], Xtv_s, dtv_s,
            cfg["best_epoch"], RANDOM_SEED + 100,
        )
        delta_pred_scaled = predict_neural(model, Xte_s, device)
        delta_pred = inverse_y(delta_pred_scaled, y_scaler_final)
        force_pred = te["F_t"] + delta_pred
        predictions[name] = {"delta": delta_pred, "force": force_pred}
        torch.save({
            "state_dict": model.state_dict(),
            "architecture": name,
            "params": cfg["params"],
            "feature_names_per_hour": THERMAL_ELECTRICAL_FEATURES,
            "window_hours": WINDOW_HOURS,
            "n_features": len(THERMAL_ELECTRICAL_FEATURES),
            "feature_scaler_mean": x_scaler_final.mean_.tolist(),
            "feature_scaler_scale": x_scaler_final.scale_.tolist(),
            "delta_scaler_mean": y_scaler_final.mean_.tolist(),
            "delta_scaler_scale": y_scaler_final.scale_.tolist(),
            "epochs": cfg["best_epoch"],
            "scenario": "C",
        }, model_dir / f"{name}_scenario_C.pt")
        final_infos[name] = {
            "params": cfg["params"],
            "best_epoch": cfg["best_epoch"],
            "validation_RMSE_force_kN": cfg["validation_RMSE_force_kN"],
        }
        print(f"[C] {name} finalise.")

    joblib.dump({"x_scaler": x_scaler_final, "delta_scaler": y_scaler_final,
                 "window_hours": WINDOW_HOURS, "feature_names": THERMAL_ELECTRICAL_FEATURES},
                model_dir / "scalers_finaux_scenario_C.joblib")

    # Sauvegarde recherche et hyperparametres.
    search_df = pd.DataFrame(search_rows).sort_values(["architecture", "RMSE_kN"])
    search_df.to_csv(out_scenario / "recherche_hyperparametres_validation.csv", index=False, encoding="utf-8-sig")
    with open(out_scenario / "hyperparametres_retenus.json", "w", encoding="utf-8") as f:
        json.dump(final_infos, f, ensure_ascii=False, indent=2, default=str)

    # Metriques test : force reconstruite ET variation predite.
    test_rows = []
    for name, pred in predictions.items():
        row = {"scenario": "C", "architecture": name}
        row.update(regression_metrics(te["F_target"], pred["force"]))
        row.update(regression_metrics(te["delta"], pred["delta"], prefix="delta_"))
        test_rows.append(row)
    metrics_df = pd.DataFrame(test_rows).sort_values("RMSE_kN")
    metrics_df.to_csv(out_scenario / "metriques_test_architectures_scenario_C.csv", index=False, encoding="utf-8-sig")

    # Baseline persistance : DeltaF=0, F_hat(t+1)=F(t).
    baseline_force = te["F_t"]
    baseline_delta = np.zeros_like(te["delta"])
    baseline_row = {"scenario": "Reference_persistance", "architecture": "DeltaF_zero_F_t"}
    baseline_row.update(regression_metrics(te["F_target"], baseline_force))
    baseline_row.update(regression_metrics(te["delta"], baseline_delta, prefix="delta_"))
    pd.DataFrame([baseline_row]).to_csv(out_scenario / "baseline_persistance_test_scenario_C.csv", index=False, encoding="utf-8-sig")

    # Predictions test par horodatage.
    pred_df = te["meta"].copy()
    pred_df["F_persistance_kN"] = te["F_t"]
    pred_df["delta_F_predite_persistance_kN"] = 0.0
    for name, pred in predictions.items():
        pred_df[f"delta_F_predite_{name}_kN"] = pred["delta"]
        pred_df[f"F_predite_{name}_kN"] = pred["force"]
        pred_df[f"erreur_{name}_kN"] = pred["force"] - te["F_target"]
    pred_df.to_csv(OUTPUT_DIR / "predictions_test_scenario_C.csv", index=False, encoding="utf-8-sig")

    # Metriques test par mois.
    month_rows = []
    months = pd.to_datetime(te["meta"][TARGET_TIME_COLUMN]).dt.to_period("M").astype(str)
    for month in sorted(months.unique()):
        mask = (months == month).to_numpy()
        for name, pred in predictions.items():
            met = regression_metrics(te["F_target"][mask], pred["force"][mask])
            month_rows.append({"mois": month, "architecture": name, **met})
        met = regression_metrics(te["F_target"][mask], te["F_t"][mask])
        month_rows.append({"mois": month, "architecture": "Persistance", **met})
    pd.DataFrame(month_rows).to_csv(OUTPUT_DIR / "metriques_test_par_mois_scenario_C.csv", index=False, encoding="utf-8-sig")

    return metrics_df, predictions, search_df, final_infos, baseline_row


# =============================================================================
# 7. RAPPORTS ET GRAPHIQUES
# =============================================================================

def create_outputs(partitions, merged, audit, force_source, n_dropped_force_t,
                   metrics_df, predictions, search_df, final_infos, baseline_row):
    out_scenario = OUTPUT_DIR / "Scenario_C"
    plot_dir = OUTPUT_DIR / "graphiques"
    make_dir(plot_dir)

    # Graphique comparaison RMSE.
    chart = metrics_df.sort_values("RMSE_kN")
    plt.figure(figsize=(10, 6))
    plt.bar(chart["architecture"], chart["RMSE_kN"])
    plt.axhline(baseline_row["RMSE_kN"], linestyle="--", label=f"Persistance : {baseline_row['RMSE_kN']:.3f} kN")
    plt.ylabel("RMSE force reconstruite (kN)")
    plt.xlabel("Architecture")
    plt.title("Scenario C — comparaison des architectures sur le test")
    plt.xticks(rotation=25, ha="right")
    plt.legend()
    plt.tight_layout()
    plt.savefig(plot_dir / "comparaison_RMSE_scenario_C.png", dpi=160)
    plt.close()

    # Graphique serie temporelle pour le meilleur modele.
    best_name = metrics_df.iloc[0]["architecture"]
    test_meta = partitions["test"]["meta"]
    plt.figure(figsize=(15, 6))
    plt.plot(test_meta[TARGET_TIME_COLUMN], partitions["test"]["F_target"], label="Force mesuree", linewidth=1.1)
    plt.plot(test_meta[TARGET_TIME_COLUMN], partitions["test"]["F_t"], label="Persistance F(t)", linewidth=0.9, alpha=0.8)
    plt.plot(test_meta[TARGET_TIME_COLUMN], predictions[best_name]["force"], label=f"Scenario C — {best_name}", linewidth=1.0)
    plt.ylabel("Force de serrage (kN)")
    plt.xlabel("Date cible")
    plt.title(f"Test chronologique — meilleur modele C : {best_name}")
    plt.legend()
    plt.tight_layout()
    plt.savefig(plot_dir / "serie_temporelle_meilleur_modele_C.png", dpi=160)
    plt.close()

    # Graphique delta mesure/predit pour le meilleur modele.
    plt.figure(figsize=(7, 7))
    plt.scatter(partitions["test"]["delta"], predictions[best_name]["delta"], s=12, alpha=0.55)
    lims = [
        min(float(np.min(partitions["test"]["delta"])), float(np.min(predictions[best_name]["delta"]))),
        max(float(np.max(partitions["test"]["delta"])), float(np.max(predictions[best_name]["delta"]))),
    ]
    plt.plot(lims, lims, linestyle="--")
    plt.xlabel("Variation mesuree DeltaF (kN)")
    plt.ylabel("Variation predite DeltaF (kN)")
    plt.title(f"Variations mesurees vs predites — {best_name}")
    plt.tight_layout()
    plt.savefig(plot_dir / "deltaF_mesuree_vs_predite.png", dpi=160)
    plt.close()

    # Rapport texte.
    all_d = merged["delta_F_target_kN"].to_numpy(dtype=float)
    test_force = partitions["test"]["F_target"]
    test_t = partitions["test"]["F_t"]
    best = metrics_df.iloc[0]
    lines = []
    lines.append("RAPPORT — SCENARIO C : PREDICTION DE LA VARIATION DE FORCE A t+1 HEURE")
    lines.append("=" * 88)
    lines.append("")
    lines.append("FORMULATION")
    lines.append("DeltaF(t+1) = F(t+1) - F(t)")
    lines.append("DeltaF_predite = modele(sequence electrothermique des 24 h jusqu'a t)")
    lines.append("F_predite(t+1) = F_mesuree(t) + DeltaF_predite(t+1)")
    lines.append("")
    lines.append("IMPORTANT : les 9 variables X sont exclusivement electrothermiques.")
    lines.append("F(t) est utilise uniquement comme offset de reconstruction, jamais comme feature.")
    lines.append(f"Source de F(t) : {force_source}")
    lines.append(f"Observations exclues faute de F(t) : {n_dropped_force_t}")
    lines.append("")
    lines.append("DONNEES ET PARTITIONS")
    for _, row in audit.iterrows():
        lines.append(f"{row['partition']}: n={int(row['n_sequences'])}, debut={row['date_cible_debut']}, fin={row['date_cible_fin']}")
    lines.append(f"X par observation : ({WINDOW_HOURS}, {len(THERMAL_ELECTRICAL_FEATURES)})")
    lines.append(f"Nombre de sequences apparies : {len(merged)}")
    lines.append(f"DeltaF moyenne globale : {np.mean(all_d):.6f} kN")
    lines.append(f"DeltaF ecart-type global : {np.std(all_d, ddof=1):.6f} kN")
    lines.append(f"DeltaF min / max : {np.min(all_d):.6f} / {np.max(all_d):.6f} kN")
    lines.append("")
    lines.append("METRIQUES TEST — FORCE RECONSTRUITE")
    lines.append(metrics_df.to_string(index=False))
    lines.append("")
    lines.append("REFERENCE PERSISTANCE (DeltaF=0 ; F_predite=F(t))")
    lines.append(json_text(baseline_row))
    lines.append("")
    lines.append("MEILLEUR MODELE SELON LE RMSE DE FORCE TEST (RESULTAT DESCRIPTIF, PAS SELECTION)")
    lines.append(f"Architecture : {best['architecture']}")
    lines.append(f"RMSE force : {best['RMSE_kN']:.6f} kN")
    lines.append(f"MAE force : {best['MAE_kN']:.6f} kN")
    lines.append(f"R2 force : {best['R2']:.6f}")
    lines.append("")
    lines.append("HYPERPARAMETRES RETENUS SUR VALIDATION")
    lines.append(json_text(final_infos))
    lines.append("")
    lines.append("LIMITES D'INTERPRETATION")
    lines.append("1. Le Scenario C est hybride : il exige une mesure F(t) pour reconstruire F(t+1).")
    lines.append("2. Le modele apprend DeltaF depuis les variables electrothermiques ; F(t) n'est pas une entree du reseau.")
    lines.append("3. Le jeu est issu d'un seul transformateur / une seule serie temporelle 2024 : generalisation externe non demontree.")
    lines.append("4. Les hyperparametres sont selectionnes sur validation ; le test final n'intervient pas dans cette selection.")
    lines.append("5. La meilleure architecture observee sur le test ne doit pas etre re-selectionnee apres examen du test.")
    (OUTPUT_DIR / "RAPPORT_SCENARIO_C_VARIATION_FORCE.txt").write_text("\n".join(lines), encoding="utf-8")

    # Resume JSON de configuration.
    config = {
        "scenario": "C",
        "target": "Delta_F(t+1) = F(t+1) - F(t)",
        "reconstruction": "F_hat(t+1) = F(t) + Delta_F_hat(t+1)",
        "feature_names_per_hour": THERMAL_ELECTRICAL_FEATURES,
        "window_hours": WINDOW_HOURS,
        "n_features": len(THERMAL_ELECTRICAL_FEATURES),
        "seed": RANDOM_SEED,
        "smoke_test": SMOKE_TEST,
    }
    (OUTPUT_DIR / "configuration_scenario_C.json").write_text(json.dumps(config, ensure_ascii=False, indent=2), encoding="utf-8")


# =============================================================================
# 8. EXECUTION PRINCIPALE
# =============================================================================

def main():
    start_all = time.time()
    make_dir(OUTPUT_DIR)

    print("=" * 78)
    print("SCENARIO C — PREDICTION DE DELTA F A t+1 HEURE")
    print("=" * 78)
    print(f"Scenario A : {SCENARIO_A_DIR}")
    print(f"Scenario B : {SCENARIO_B_DIR}")
    print(f"Sortie     : {OUTPUT_DIR}")
    print(f"Mode test rapide : {SMOKE_TEST}")
    print("Cible : DeltaF(t+1) = F(t+1) - F(t)")
    print("Entrees : 9 variables electrothermiques x 24 heures")

    if not torch.cuda.is_available():
        print("PyTorch utilisera le CPU.")
    else:
        print(f"PyTorch utilisera le GPU : {torch.cuda.get_device_name(0)}")

    partitions, merged, audit, force_source, n_dropped = load_and_align_scenarios()
    audit.to_csv(OUTPUT_DIR / "resume_partitions_scenario_C.csv", index=False, encoding="utf-8-sig")

    print("\nPartitions apparies :")
    print(audit.to_string(index=False))
    print(f"F(t) provient de : {force_source}")
    print(f"Nombre de F(t) indisponibles exclus : {n_dropped}")
    print("\nStatistiques delta F (kN) :")
    print(merged["delta_F_target_kN"].describe().to_string())

    metrics_df, predictions, search_df, final_infos, baseline_row = run_experiment(partitions)
    create_outputs(partitions, merged, audit, force_source, n_dropped,
                   metrics_df, predictions, search_df, final_infos, baseline_row)

    print("\n" + "=" * 78)
    print("SCENARIO C TERMINE")
    print("=" * 78)
    print(f"Dossier : {OUTPUT_DIR}")
    print("\nMetriques test (force reconstruite) :")
    print(metrics_df[["architecture", "n", "MAE_kN", "RMSE_kN", "R2", "Biais_moyen_kN"]].to_string(index=False))
    print("\nReference persistance :")
    print(pd.DataFrame([baseline_row])[["architecture", "n", "MAE_kN", "RMSE_kN", "R2"]].to_string(index=False))
    print(f"\nDuree totale : {(time.time() - start_all) / 60:.1f} minutes")
    print("Ouvre RAPPORT_SCENARIO_C_VARIATION_FORCE.txt, puis compresse le dossier complet.")


if __name__ == "__main__":
    warnings.filterwarnings("ignore", category=UserWarning, module="xgboost")
    main()
